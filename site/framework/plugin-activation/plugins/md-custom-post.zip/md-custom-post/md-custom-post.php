<?php
/*
Plugin Name: MD Custom Post
Plugin URI: http://www.themesholic.com
Description: Custom Posts Type for Themesholic Themes.
Author: Themesholic
Author URI: http://www.themesholic.com
Version: 2.0
*/

/* Init Metabox */
$md_metabox = array();

/* Custom Post */
require_once('custom-post/md-portfolio.php');
require_once('custom-post/md-team.php');
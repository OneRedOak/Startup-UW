<?php

/*
*	
*	CUSTOM POST TYPE: TEAM
*
*
*/


function custom_post_team()
{
	
	$labels = array(
		'name' 					=> __('Team', MD_THEME_NAME),
		'singular_name' 		=> __('Team Item', MD_THEME_NAME),
		'menu_name'          	=> __('Team', MD_THEME_NAME),
		'all_items'          	=> __('All Team Items', MD_THEME_NAME),
		'add_new' 				=> __('Add New Item', MD_THEME_NAME),
		'add_new_item' 			=> __('Add New Team Item', MD_THEME_NAME),
		'edit_item' 			=> __('Edit Team Item', MD_THEME_NAME),
		'new_item'				=> __('New Team Item', MD_THEME_NAME),
		'view_item'				=> __('View Team Item', MD_THEME_NAME),
		'search_items' 			=> __('Search Items', MD_THEME_NAME),
		'not_found' 			=> __('No Team Items Found', MD_THEME_NAME),
		'not_found_in_trash' 	=> __('No Team Items Found in Trash', MD_THEME_NAME),
		'parent_item_colon' 	=> __('Parent', MD_THEME_NAME),
	);
	
	$args = array(
		'labels'              	=> $labels,
		'public'             	=> true,
		'supports'            	=> array( 'title', 'thumbnail'),
		'rewrite'             	=> array( 'slug' => __('team', MD_THEME_NAME) ),
		'exclude_from_search'	=> true
	);

	register_post_type( 'team', $args );

}
add_action( 'init', 'custom_post_team' );


if(isset($_GET['post']) || isset($_POST['post_ID']))
{

	$post_id = isset($_GET['post']) ? $_GET['post'] : $_POST['post_ID'] ;

	if('team' == get_post_type($post_id)){


	$fields = array(
		array(
			'name'  => 'team_name',
			'label' => 'Name',
			'type'  => 'textfield'
		),
		array(
			'name'  => 'team_role',
			'label' => 'Role',
			'type'  => 'textfield'
		),
		array(
			'name'  => 'team_thumb',
			'label' => 'Image',
			'type'  => 'upload',
			'media'	=> 'image'
		),
		array(
			'name'  => 'team_text',
			'label' => 'Text',
			'type'  => 'textarea_html'
		),
		array(
			'name'  => 'team_email',
			'label' => 'Email User',
			'type'  => 'textfield'
		),
		array(
			'name'  => 'team_website',
			'label' => 'Website User',
			'type'  => 'textfield'
		),
		array(
			'name'  => 'team_facebook',
			'label' => 'Facebook Url Profile',
			'type'  => 'textfield'
		),
		array(
			'name'  => 'team_twitter',
			'label' => 'Twitter Url Profile',
			'type'  => 'textfield'
		),
		array(
			'name'  => 'team_google-plus',
			'label' => 'Google+ Url Profile',
			'type'  => 'textfield'
		),
		array(
			'name'  => 'team_instagram',
			'label' => 'Instragram Url Profile',
			'type'  => 'textfield'
		),
		array(
			'name'  => 'team_youtube',
			'label' => 'Youtube Url Profile',
			'type'  => 'textfield'
		),
		array(
			'name'  => 'team_dribbble',
			'label' => 'Dribbble Url Profile',
			'type'  => 'textfield'
		),
		array(
			'name'  => 'team_skype',
			'label' => 'Skype Url Profile',
			'type'  => 'textfield'
		),
		array(
			'name'  => 'team_linkedin',
			'label' => 'Linkedin Url Profile',
			'type'  => 'textfield'
		),
		array(
			'name'  => 'team_foursquare',
			'label' => 'Foursquare Url Profile',
			'type'  => 'textfield'
		),
		array(
			'name'  => 'team_github',
			'label' => 'Github Url Profile',
			'type'  => 'textfield'
		),
	);

	$md_metabox['team']['order'] = 99;
	$md_metabox['team']['title'] = 'Team Options';
	$md_metabox['team']['icon'] = 'group';
	$md_metabox['team']['fields'] = $fields;

	}
}
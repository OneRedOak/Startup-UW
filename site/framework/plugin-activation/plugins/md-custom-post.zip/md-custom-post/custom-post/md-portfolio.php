<?php

/*
*	
*	CUSTOM POST TYPE: PORTFOLIO
*
*
*/


function custom_post_portfolio()
{
	
	$labels = array(
		'name' 					=> 'Portfolio',
		'singular_name' 		=> 'Portfolio Item',
		'menu_name'          	=> 'Portfolio',
		'all_items'          	=> 'All Portfolio Items',
		'add_new' 				=> 'Add New Item',
		'add_new_item' 			=> 'Add New Portfolio Item',
		'edit_item' 			=> 'Edit Portfolio Item',
		'new_item'				=> 'New Portfolio Item',
		'view_item'				=> 'View Portfolio Item',
		'search_items' 			=> 'Search Items',
		'not_found' 			=> 'No Portfolio Items Found',
		'not_found_in_trash' 	=> 'No Portfolio Items Found in Trash',
		'parent_item_colon' 	=> 'Parent',
	);
	
	$args = array(
		'labels'              	=> $labels,
		'public'             	=> true,
		'supports'            	=> array( 'title', 'thumbnail', 'editor'),
		'rewrite'             	=> array( 'slug' => 'portfolio' ),
		'exclude_from_search'	=> true
	);

	register_post_type( 'portfolio', $args );


	$portfolio_category = array(
		'name' 					=> 'Portfolio Categories',
		'singular_name' 		=> 'Portfolio Category',
		'search_items' 			=> 'Search Portfolio Categories',
		'all_items' 			=> 'All Portfolio Categories',
		'parent_item' 			=> 'Parent Portfolio Category',
		'edit_item' 			=> 'Edit Portfolio Category',
		'update_item' 			=> 'Update Portfolio Category',
		'add_new_item' 			=> 'Add New Portfolio Category',
		'menu_name' 			=> 'Portfolio Categories'
	); 	
	
	register_taxonomy(
		'portfolio-category', 
		'portfolio', 
		array("hierarchical" 	=> true, 
			'labels' 			=> $portfolio_category,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var' 		=> true,
			'rewrite' 			=> array( 'slug' => 'portfolio-category')
		)
	);

	$portfolio_tags = array(
		'name' 					=> 'Portfolio Tags',
		'singular_name' 		=> 'Portfolio Tag',
		'search_items' 			=> 'Search Portfolio Tag',
		'all_items' 			=> 'All Portfolio Tag',
		'parent_item' 			=> 'Parent Portfolio Tag',
		'edit_item' 			=> 'Edit Portfolio Tag',
		'update_item' 			=> 'Update Portfolio Tag',
		'add_new_item' 			=> 'Add New Portfolio Tag',
		'menu_name' 			=> 'Portfolio Tag'
	); 	
	
	/*
	register_taxonomy(
		'portfolio-tag', 
		'portfolio', 
		array("hierarchical" 	=> true, 
			'labels' 			=> $portfolio_tags,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var' 		=> true,
			'rewrite' 			=> array( 'slug' => 'portfolio-tag')
		)
	);
	*/

}
add_action( 'init', 'custom_post_portfolio' );


function custom_post_portfolio_tpl( $template_path ) {
if ( get_post_type() == 'portfolio' ) {
	if ( is_single() ) {
		if ( $theme_file = locate_template( array
			( 'single-portfolio.php' ) ) ) {
			$template_path = $theme_file;
		} else {
			$template_path = plugin_dir_path( __FILE__ ) . 'templates/single-portfolio.php';
		}
	}
}
return $template_path;
}
add_filter( 'template_include', 'custom_post_portfolio_tpl', 1 );



if(isset($_GET['post']) || isset($_POST['post_ID']))
{

	$post_id = isset($_GET['post']) ? $_GET['post'] : $_POST['post_ID'] ;

	if('portfolio' == get_post_type($post_id)){


	$fields = array(
		array(
			'name'  => 'portfolio_preview_thumb',
			'label' => 'Preview Thumb',
			'desc'	=> 'Choose your Thumb Preview',
			'type'  => 'upload',
			'media'	=> 'image'
		),
		array(
			'name'  => 'portfolio_preview_text',
			'label' => 'Preview Text',
			'desc'	=> 'Text for the preview.',
			'type'  => 'textarea'
		),
		/*
		array(
			'name'  => 'portfolio_show_categories',
			'label' => 'Show Categories',
			'desc'	=> 'Enable / disable Categories',
			'type'  => 'toggle'
		),
		array(
			'name'  => 'portfolio_show_tags',
			'label' => 'Show Tags',
			'desc'	=> 'Enable / disable tags',
			'type'  => 'toggle'
		),
		*/

	);

	$md_metabox['portfolio']['order'] = 99;
	$md_metabox['portfolio']['title'] = 'Portfolio Options';
	$md_metabox['portfolio']['icon'] = 'camera';
	$md_metabox['portfolio']['fields'] = $fields;

	}
}
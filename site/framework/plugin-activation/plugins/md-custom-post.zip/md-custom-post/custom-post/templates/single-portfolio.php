<?php get_header(); ?>

<div id="content">

<?php if(have_posts()) : while(have_posts()) : the_post(); ?>
	<?php $page_options = get_post_custom( $post->ID ); ?>
	

	<?php md_theme_header(); ?>
	
	<?php md_theme_rev_slider(); ?>
	<div class="container">
	<?php the_content(); ?>
	</div>
	<?php if($theme_options['portfolio-pagination-enabled']){ ?>
	<div class="md-portfolio-pagination">
		<div class="container">
			<span class="prev"><?php echo previous_post_link('%link', $theme_options['portfolio-pagination-prev']); ?></span>
			<?php if ($theme_options['portfolio-pagination-grid-url']){ ?>
			<span class="list"><a href="<?php echo $theme_options['portfolio-pagination-grid-url'];?>"><?php echo $theme_options['portfolio-pagination-grid'];?></a></span>
			<?php } ?>

			<span class="next"><?php echo next_post_link('%link', $theme_options['portfolio-pagination-next']); ?></span>
		</div>
	</div>
	<?php } ?>
	
<?php endwhile; endif; ?>

</div>

<?php get_footer(); ?>
<?php
/*
Plugin Name: MD Page Builder
Plugin URI: http://www.themesholic.com
Description: Page Builder and Shortcodes for Themesholic Themes.
Author: Themesholic
Author URI: http://www.themesholic.com
Version: 2.0
*/

/* Get Theme Options */
$theme_options = get_option(wp_get_theme());

/* Visual Composer */
require_once ('js_composer/js_composer.php');

/* Shortcodes */
require_once ('md-shortcodes/md-shortcodes.php');
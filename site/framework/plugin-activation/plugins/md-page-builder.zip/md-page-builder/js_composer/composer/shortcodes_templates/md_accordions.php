<?php

if(file_exists(get_template_directory().'/framework/shortcodes/templates/md_accordions.php')){
  require_once (get_template_directory().'/framework/shortcodes/templates/md_accordions.php');
}

else{

extract(shortcode_atts(array(
    'class' 		=> '',
    'id' 			=> '',
    'css_animation' => '',
    'css_animation_delay' => '',
    'expanded' 		=> '',
    'fill' 			=> '',
    'color_scheme' 	=> '',
    'custom_color' 	=> ''
), $atts));

$animated = ($css_animation) ? 'animate' : '';
$css_animation_delay = ($css_animation) ? ' data-delay="'.$css_animation_delay.'"' : '';

$class  = setClass(array('md-accordions', $animated, $css_animation, $class, $expanded, $fill, $color_scheme));
$id 	= setId($id);
$uid	= 'acc_'.uniqid();

if($custom_color && $color_scheme == 'custom' && $fill == 'fill')
$GLOBALS['acc_bg'] = $custom_color; 


if($custom_color && $color_scheme == 'custom' && $fill == 'no-fill')
$GLOBALS['acc_border'] = $custom_color; 


$output = '<div'.$class.$id.$css_animation_delay.'>';
$output .= '<div class="panel-group" id="'.$uid.'">';
$output .= wpb_js_remove_wpautop($content);
$output .= '</div>';
$output .= '</div>';

$GLOBALS['acc_bg'] = null;
$GLOBALS['acc_border'] = null;

echo $output;

}
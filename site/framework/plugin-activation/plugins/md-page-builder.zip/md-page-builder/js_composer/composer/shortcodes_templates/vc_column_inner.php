<?php
extract(shortcode_atts(array(
    'class' 		=> '',
    'id' 			=> '',
    'css_animation' => '',
    'css_animation_delay' => '',
    'width' 		=> '1/1',
    'text_align' 	=> '',
), $atts));

$width = wpb_translateColumnWidthToSpan($width);

$animated = ($css_animation) ? 'animate' : '';
$css_animation_delay = ($css_animation) ? ' data-delay="'.$css_animation_delay.'"' : '';

$class  = setClass(array('col-md-'.$width, 'col-sm-'.$width, $animated, $css_animation, $class, $text_align));
$id 	= setId($id);

$output .= "\n\t\t\t".'<div'.$class.$id.$css_animation_delay.'>';
$output .= wpb_js_remove_wpautop($content);
$output .= "\n\t\t\t".'</div>';

echo $output;
<?php
/**
 *
 * MD Shortcodes Dropcap
 *
 */

if(file_exists(get_template_directory().'/framework/shortcodes/lib/md_gallery.php')){
  require_once (get_template_directory().'/framework/shortcodes/lib/md_gallery.php');
}

else{

$element_options['items_cols']['dependency'] = array('element' => "type", 'value' => array('lightbox'));
$element_options['items_cols_tablet']['dependency'] = array('element' => "type", 'value' => array('lightbox'));

$md_shortcodes['md_gallery'] = array(
  "name"            => __("Gallery", "js_composer"),
  "base"            => "md_gallery",
  "modal"           => false,
  "params"          => array(
    array(
      "type"        => "radio",
      "heading"     => __("Gallery Type", "js_composer"),
      "param_name"  => "type",
      "value"       => array(
      __('Lightbox', "js_composer")   => "lightbox", 
      __('Slider', "js_composer")     => "slider", 
      __('Stacked', "js_composer")    => "stacked", 
      ),
      "default"     => "lightbox",
      "description" => __("Select Gallery type.", "js_composer")
    ),
    array(
      "type"        => "attach_images",
      "heading"     => __("Images", "js_composer"),
      "param_name"  => "images",
      "description" => __("Select Images.", "js_composer"),
    ),
    $element_options['items_cols'],
    $element_options['items_cols_tablet'],
    $element_options['class'],
    $element_options['id'],
    $element_options['css_animation'],
    $element_options['css_animation_delay'],
  )
);

}

vc_map( $md_shortcodes['md_gallery'] );

class WPBakeryShortCode_MD_Gallery extends WPBakeryShortCode {}
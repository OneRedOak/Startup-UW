<?php
/**
 *
 * MD Shortcodes Raw HTML
 *
 */


if(file_exists(get_template_directory().'/framework/shortcodes/lib/md_raw_html.php')){
  require_once (get_template_directory().'/framework/shortcodes/lib/md_raw_html.php');
}

else{

$md_shortcodes['md_raw_html'] = array(
  "name"            => __("Raw HTML", "js_composer"),
  "base"            => "md_raw_html",
  "modal"           => false,
  "params"          => array(
    array(
      "type"        => "textarea",
      "heading"     => __("Text", "js_composer"),
      "param_name"  => "content",
      "value"       => "",
      "description" => __("Put your Raw HTML Here.", "js_composer")
    )
  )
);

}

vc_map($md_shortcodes['md_raw_html'] );

class WPBakeryShortCode_MD_Raw_html extends WPBakeryShortCode {}
<?php
/**
 *
 * MD Shortcodes Heading
 *
 */

if(file_exists(get_template_directory().'/framework/shortcodes/lib/md_heading.php')){
  require_once (get_template_directory().'/framework/shortcodes/lib/md_heading.php');
}

else{


$md_shortcodes['md_heading'] = array(
  "name"            => __("Heading", "js_composer"),
  "base"            => "md_heading",
  "modal"           => true,
  "params"          => array(
    array(
      "type"        => "textfield",
      "heading"     => __("Text", "js_composer"),
      "param_name"  => "content",
      "shortcode_btn"  => true,
      "value"       => ""
    ),
    array(
      "type"        => "radio",
      "heading"     => __("Type", "js_composer"),
      "param_name"  => "kind",
      "value"       => array(
        __('H1', "js_composer")    => "h1", 
        __('H2', "js_composer")    => "h2", 
        __('H3', "js_composer")    => "h3", 
        __('H4', "js_composer")    => "h4", 
        __('H5', "js_composer")    => "h5", 
        __('H6', "js_composer")    => "h6", 
      ),
      "default"     => 'h1',
    ),
    $element_options['text_align'],
    array(
      "type"        => "radio",
      "heading"     => __("Special Font", "js_composer"),
      "param_name"  => "special_font",
      "value"       => array(
        __('No', "js_composer") => "", 
        __('Yes', "js_composer") => "special-font", 
      ),
      "default"     => ""
    ),
    array(
      "type"        => "radio",
      "heading"     => __("Color Scheme", "js_composer"),
      "param_name"  => "color_scheme",
      "value"       => array(
        __('Default', "js_composer") => "", 
        __('Accent Color', "js_composer") => "accent", 
        __('Custom', "js_composer") => "custom", 
      ),
      "default"     => ""
    ),
    array(
      "type"        => "colorpicker",
      "heading"     => __("Color", "js_composer"),
      "param_name"  => "color",
      "value"       => '#444',
      "dependency"  => array('element' => 'color_scheme', 'value' => 'custom')
    ),
    array(
      "type"        => "radio",
      "heading"     => __("Size & Line Height", "js_composer"),
      "param_name"  => "size",
      "value"       => array(
        __('Default', "js_composer") => "", 
        __('Custom', "js_composer") => "custom", 
      ),
      "default"     => ""
    ),
    array(
      "type"        => "textfield",
      "heading"     => __("Font Size", "js_composer"),
      "param_name"  => "fontsize",
      "value"       => '',
      "dependency"  => array('element' => 'size', 'value' => 'custom'),
      "description" => 'Insert font size with px (eg. 20px)'
    ),
    array(
      "type"        => "textfield",
      "heading"     => __("Line Height", "js_composer"),
      "param_name"  => "lineheight",
      "value"       => '',
      "dependency"  => array('element' => 'size', 'value' => 'custom'),
      "description" => 'Insert line height with px (eg. 20px)'
    ),
    $element_options['class'],
    $element_options['id'],
    $element_options['css_animation'],
    $element_options['css_animation_delay'],
  )
);

}

vc_map( $md_shortcodes['md_heading'] );

class WPBakeryShortCode_MD_Heading extends WPBakeryShortCode {}
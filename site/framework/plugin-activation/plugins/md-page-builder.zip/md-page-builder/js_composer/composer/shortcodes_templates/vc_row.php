<?php
extract(shortcode_atts(array(
    'class' 				=> '',
    'id' 					=> '',
    'css_animation'         => '',
    'css_animation_delay'   => '',
    'container_type' 		=> '',
    'padding' 				=> '',
    'padding_top' 			=> '',
    'padding_bottom' 		=> '',
    'fixed_height' 			=> '',
    'bgtype' 				=> '',
    'bgcolor' 				=> '',
    'bgimage' 		        => '',
    'bgvideo' 			    => '',
    'video_mp4'             => '',
    'video_webm'            => '',
    'video_ogv'             => '',
    'video_poster'          => '',
    'bgparallax'            => '',
    'bgmask'                => '',
    'bgmask_color'          => '',
    'bgimage_position' 	    => '',
    'bgimage_repeat' 		=> '',
    'bgimage_size' 		    => '',
    'bgimage_attach' 		=> '',
), $atts));


$animated = ($css_animation) ? 'animate' : '';
$css_animation_delay = ($css_animation) ? ' data-delay="'.$css_animation_delay.'"' : '';

$bgparallax = ($bgparallax == 'bg-parallax' && $bgtype == 'bgimage') ? 'bg-parallax' : '';

if($container_type == 'container'){
    $container_type = '';
}

$class  = setClass(array($class, $animated, $css_animation, $container_type, $padding, $bgtype, $bgparallax));
$id 	= setId($id);

$s_height = ($fixed_height) ? 'height:'.$fixed_height.';' : '';
$s_padding = '';
if($padding == 'custom'){
    $s_padding = 'padding-top:'.$padding_top.'; padding-bottom:'.$padding_bottom.';';
}


$s_bgimage = '';
$s_parallax = '';
$s_bgposition = '';
$s_bgrepeat = '';
$s_bgsize = '';
$s_bgattachment = '';
if ($bgtype == 'bgimage') {

    $bgimage = wp_get_attachment_image_src( $bgimage, 'full');    
    $s_bgimage = 'background-image:url('.$bgimage[0].');';
    
    if($bgparallax){
        $s_parallax = ' data-type="background" data-speed="2"';
    }
    else{
        $s_bgposition = 'background-position:'.$bgimage_position.';';
        $s_bgrepeat = 'background-repeat:'.$bgimage_repeat.';';
        $s_bgsize = 'background-size:'.$bgimage_size.';';
        $s_bgattachment = 'background-attachment:'.$bgimage_attach.';';
    }
}
$s_bgcolor = ($bgtype == 'bgcolor') ? 'background-color:'.$bgcolor.';' : '';


$style = ' style="'.$s_padding.$s_height.$s_bgcolor.$s_bgimage.$s_bgposition.$s_bgrepeat.$s_bgsize.$s_bgattachment.'"';
$output = '<section'.$class.$id.$css_animation_delay.$style.$s_parallax.'>';

if($bgmask){
    $output .= '<div class="mask" style="background-color:'.$bgmask_color.'"></div>';
}


if($bgtype == 'bgvideo'){

    $poster = ($video_poster) ? $video_poster : '';
    if($poster)
    {
        $poster = wp_get_attachment_image_src( $poster, 'full');    
        $poster = ' poster="'.$poster[0].'"';
    }
    $output .= '<div class="section-video">';
    $output .= '<video'.$poster.' loop style="width: 100%; height: 100%;">';
    if($video_mp4)
    $output .= '<source type="video/mp4" src="'.$video_mp4.'" />';

    if($video_webm)
    $output .= '<source type="video/webm" src="'.$video_webm.'" />';

    if($video_ogv)
    $output .= '<source type="video/ogg" src="'.$video_ogv.'" />';
    $output .= '</video>';

    $output .= '</div>';
}

$output .= '<div class="section-content">';
$output .= wpb_js_remove_wpautop($content);
$output .= '</div>';
$output .= '</section>';



echo $output;


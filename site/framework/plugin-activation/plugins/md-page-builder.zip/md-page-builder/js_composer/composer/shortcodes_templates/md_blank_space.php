<?php

if(file_exists(get_template_directory().'/framework/shortcodes/templates/md_blank_space.php')){
  require_once (get_template_directory().'/framework/shortcodes/templates/md_blank_space.php');
}

else{
extract(shortcode_atts(array(
    'class' 		=> '',
    'id' 			=> '',
    'height'  		=> '',
), $atts));

$class  = setClass(array('clearfix', $class));
$id     = setId($id);

$output .= '<div'.$class.$id.' style="height:'.$height.'"></div>';

echo $output;

}
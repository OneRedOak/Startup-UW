<?php
/**
 *
 * MD Shortcodes Progress Bar
 *
 */

if(file_exists(get_template_directory().'/framework/shortcodes/lib/md_progress_bar.php')){
  require_once (get_template_directory().'/framework/shortcodes/lib/md_progress_bar.php');
}

else{

$md_shortcodes['md_progress_bar'] = array(
  "name"            => __("Progress Bar", "js_composer"),
  "base"            => "md_progress_bar",
  "modal"           => true,
  "params"          => array(
    array(
      "type"        => "textfield",
      "heading"     => __("Percent", "js_composer"),
      "param_name"  => "percent",
      "value"       => "",
      "description" => __("Set the percent value (0-100 without %).", "js_composer")
    ),
    array(
      "type"        => "textfield",
      "heading"     => __("Label", "js_composer"),
      "param_name"  => "content",
      "value"       => "",
      "description" => __("Set the label.", "js_composer")
   ),
    array(
      "type"        => "radio",
      "heading"     => __("Start Animated", "js_composer"),
      "param_name"  => "start_animated",
      "value"       => array(
        __('Yes', "js_composer") => "start-animated", 
        __('No', "js_composer") => "start-fixed", 
      ),
      "default"     => "start-animated"
    ),
    array(
      "type"        => "radio",
      "heading"     => __("Color Scheme", "js_composer"),
      "param_name"  => "color_scheme",
      "value"       => array(
        __('Accent Color', "js_composer") => "accent", 
        __('Custom', "js_composer") => "custom", 
      ),
      "default"     => "accent"
    ),
    array(
      "type"        => "colorpicker",
      "heading"     => __("Custom Background", "js_composer"),
      "param_name"  => "bgcolor",
      "value"       => $theme_options['accent-color'],
      "description" => __("Select custom background color.", "js_composer"),
      "dependency"  => array('element' => 'color_scheme', 'value' => 'custom')
   ),
    array(
      "type"        => "colorpicker",
      "heading"     => __("Custom Color", "js_composer"),
      "param_name"  => "color",
      "value"       => '#ffffff',
      "description" => __("Select custom color.", "js_composer"),
      "dependency"  => array('element' => 'color_scheme', 'value' => 'custom')
   ),
    $element_options['class'],
    $element_options['id'],
    $element_options['css_animation'],
    $element_options['css_animation_delay'],
  )
);

}

vc_map( $md_shortcodes['md_progress_bar'] );

class WPBakeryShortCode_MD_Progress_Bar extends WPBakeryShortCode {}
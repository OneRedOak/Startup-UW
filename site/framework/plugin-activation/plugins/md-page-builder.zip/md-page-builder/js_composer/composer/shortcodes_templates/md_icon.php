<?php

if(file_exists(get_template_directory().'/framework/shortcodes/templates/md_icon.php')){
  require_once (get_template_directory().'/framework/shortcodes/templates/md_icon.php');
}

else{

extract(shortcode_atts(array(
    'class' 		=> '',
    'id'			=> '',
    'css_animation' => '',
    'css_animation_delay' => '',
    'icon'          => '',
    'icon_scheme'   => '',
    'icon_size'     => '',
    'icon_style'    => '',
    'icon_color'    => '',
    'icon_margin'   => '',
), $atts));


$animated = ($css_animation) ? 'animate' : '';
$css_animation_delay = ($css_animation) ? ' data-delay="'.$css_animation_delay.'"' : '';

$class  = setClass(array('md-icon', $animated, $css_animation, $icon, $icon_scheme, $icon_size, $icon_style));
$id     = setId($id);
$style  = '';

$s_margin = '';
if($icon_margin){
    $s_margin = 'margin:'.$icon_margin.';';
}

$s_icon = '';
if($icon_scheme == 'custom'){

    switch ($icon_style){

        case 'icon-round':
        case 'icon-circled':
           $s_icon = 'border-color:'.$icon_color.'; color:'.$icon_color.';';
        break;

        case 'icon-round fill':
        case 'icon-circled fill':
            $s_icon = 'border-color:'.$icon_color.'; background-color:'.$icon_color.';';
        break;

        default:
            $s_icon = 'color:'.$icon_color.';';
        break;

    }
}

if($s_margin || $s_icon)
$style = ' style="'.$s_margin.$s_icon.'"';

$output = '<i'.$class.$id.$style.$css_animation_delay.'></i>';

echo $output;

}
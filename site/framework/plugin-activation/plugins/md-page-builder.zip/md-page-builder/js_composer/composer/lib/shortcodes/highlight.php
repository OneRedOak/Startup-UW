<?php
/**
 *
 * MD Shortcodes HighLight
 *
 */

if(file_exists(get_template_directory().'/framework/shortcodes/lib/md_highlight.php')){
  require_once (get_template_directory().'/framework/shortcodes/lib/md_highlight.php');
}

else{


$md_shortcodes['md_highlight'] = array(
  "name"            => __("Highlight", "js_composer"),
  "base"            => "md_highlight",
  "modal"           => true,
  "content_element" => false,
  "params"          => array(
    array(
      "type"        => "textfield",
      "heading"     => __("Text", "js_composer"),
      "param_name"  => "content",
      "value"       => ""
    ),
    array(
      "type"        => "radio",
      "heading"     => __("Color Scheme", "js_composer"),
      "param_name"  => "color_scheme",
      "value"       => array(
        __('Accent Color', "js_composer") => "accent", 
        __('Custom', "js_composer") => "custom", 
      ),
      "default"     => "accent"
    ),
    array(
      "type"        => "colorpicker",
      "heading"     => __("Background Color", "js_composer"),
      "param_name"  => "bgcolor",
      "value"       => $theme_options['accent-color'],
      "dependency"  => array('element' => 'color_scheme', 'value' => 'custom')
    ),
    array(
      "type"        => "colorpicker",
      "heading"     => __("Color", "js_composer"),
      "param_name"  => "color",
      "value"       => '#ffffff',
      "dependency"  => array('element' => 'color_scheme', 'value' => 'custom')
    ),
    $element_options['class'],
    $element_options['id'],
    $element_options['css_animation'],
    $element_options['css_animation_delay'],
  )
);

}

vc_map( $md_shortcodes['md_highlight'] );

class WPBakeryShortCode_MD_Highlight extends WPBakeryShortCode {}
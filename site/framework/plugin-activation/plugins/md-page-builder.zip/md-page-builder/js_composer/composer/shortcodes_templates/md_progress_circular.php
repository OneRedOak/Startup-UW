<?php

if(file_exists(get_template_directory().'/framework/shortcodes/templates/md_progress_circular.php')){
  require_once (get_template_directory().'/framework/shortcodes/templates/md_progress_circular.php');
}

else{

extract(shortcode_atts(array(
    'class' 		=> '',
    'id' 			=> '',
    'css_animation' => '',
    'css_animation_delay' => '',
    'percent' 		=> '',
    'label_color' 	=> '',
    'percent_color' => '',
    'barcolor' 		=> '',
    'trackcolor' 	=> '',
    'scalecolor' 	=> '',
    'linecap' 		=> '',
    'linewidth' 	=> '',
    'size' 			=> '',
    'animate' 		=> '',
), $atts));

$animated = ($css_animation) ? 'animate' : '';
$css_animation_delay = ($css_animation) ? ' data-delay="'.$css_animation_delay.'"' : '';

$class  = setClass(array('md-progress-circular', $animated, $css_animation, $class));
$id     = setId($id);

$output .= '<div'.$class.$id.$css_animation_delay.' data-chart-size="'.$size.'" data-line-width="'.$linewidth.'" data-bar-color="'.$barcolor.'" data-track-color="'.$trackcolor.'" data-line-cap="'.$linecap.'" data-scale-color="'.$scalecolor.'" data-animate="'.$animate.'" data-percent="'.$percent.'">';
$output .= '<span class="lbl" style="color:'.$label_color.'">'.wpb_js_remove_wpautop($content).'</span>';
$output .= '<span class="perc" style="color:'.$percent_color.'">'.$percent.'%</span>';
$output .= '</div>';

echo $output;

}

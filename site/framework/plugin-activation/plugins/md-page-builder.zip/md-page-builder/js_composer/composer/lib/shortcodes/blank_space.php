<?php
/**
 *
 * MD Shortcodes Blank Space
 *
 */

if(file_exists(get_template_directory().'/framework/shortcodes/lib/md_blank_space.php')){
  require_once (get_template_directory().'/framework/shortcodes/lib/md_blank_space.php');
}

else{

$md_shortcodes['md_blank_space'] = array(
  "name"            => __("Blank Space", "js_composer"),
  "base"            => "md_blank_space",
  "modal"           => true,
  "params"          => array(
    array(
      "type"        => "textfield",
      "heading"     => __("Height", "js_composer"),
      "param_name"  => "height",
      "value"       => "40px",
      "description" => __("Set the height (eg. 40px)", "js_composer")
    ),
    $element_options['class'],
    $element_options['id'],
  )
);
}

vc_map( $md_shortcodes['md_blank_space'] );

class WPBakeryShortCode_MD_Blank_space extends WPBakeryShortCode {}
<?php
/**
 *
 * MD Shortcodes Call To Action
 *
 */

if(file_exists(get_template_directory().'/framework/shortcodes/lib/md_cta.php')){
  require_once (get_template_directory().'/framework/shortcodes/lib/md_cta.php');
}

else{


$md_shortcodes['md_cta'] = array(
  "name"            => __("Call To Action", "js_composer"),
  "base"            => "md_cta",
  "modal"           => false,
  "params"          => array(
    array(
      "type"        => "textarea_html",
      "heading"     => __("Text", "js_composer"),
      "param_name"  => "content",
      "shortcode_btn"  => true,
      "value"       => ""
    ),
    array(
      "type"        => "radio",
      "heading"     => __("Color Scheme", "js_composer"),
      "param_name"  => "color_scheme",
      "value"       => array(
        __('Default', "js_composer") => "", 
        __('Accent Color', "js_composer") => "accent", 
        __('Custom', "js_composer") => "custom", 
      ),
      "default"     => ""
    ),
    array(
      "type"        => "colorpicker",
      "heading"     => __("Background Color", "js_composer"),
      "param_name"  => "bgcolor",
      "value"       => $theme_options['accent-color'],
      "dependency"  => array('element' => 'color_scheme', 'value' => 'custom')
    ),
    $element_options['class'],
    $element_options['id'],
    $element_options['css_animation'],
    $element_options['css_animation_delay'],
  )
);

}
vc_map($md_shortcodes['md_cta'] );

class WPBakeryShortCode_MD_Cta extends WPBakeryShortCode {}
<?php

if(file_exists(get_template_directory().'/framework/shortcodes/templates/md_raw_html.php')){
  require_once (get_template_directory().'/framework/shortcodes/templates/md_raw_html.php');
}

else{

extract(shortcode_atts(array(
), $atts));


$output = wpb_js_remove_wpautop($content);

echo $output;

}

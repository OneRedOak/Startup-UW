<?php

if(file_exists(get_template_directory().'/framework/shortcodes/templates/md_alert.php')){
  require_once (get_template_directory().'/framework/shortcodes/templates/md_alert.php');
}

else{

extract(shortcode_atts(array(
    'class' 			=> '',
    'id' 				=> '',
    'css_animation' => '',
    'css_animation_delay' => '',
    'kind' 				=> 'info'

), $atts));

$animated = ($css_animation) ? 'animate' : '';
$css_animation_delay = ($css_animation) ? ' data-delay="'.$css_animation_delay.'"' : '';

$class  = setClass(array('md-alert', $animated, $css_animation, $class, $kind));
$id 	= setId($id);

$output .= '<div'.$class.$id.$css_animation_delay.'>';
$output .= wpb_js_remove_wpautop($content);
$output .= '<a href="#" class="message-close"><i class="icon-remove"></i></a>';
$output .= '</div>';

echo $output;

}
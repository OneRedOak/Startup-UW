<?php

if(file_exists(get_template_directory().'/framework/shortcodes/templates/md_special_heading.php')){
  require_once (get_template_directory().'/framework/shortcodes/templates/md_special_heading.php');
}

else{
extract(shortcode_atts(array(
    'class' 		=> '',
    'id' 			=> '',
    'css_animation' => '',
    'css_animation_delay' => '',
    'align'			=> '',
    'special_font'  => '',
), $atts));

$animated = ($css_animation) ? 'animate' : '';
$css_animation_delay = ($css_animation) ? ' data-delay="'.$css_animation_delay.'"' : '';

$class  = setClass(array('md-special-heading', $animated, $css_animation, $class, $align, $special_font));
$id 	= setId($id);

$output = '<h2'.$class.$id.$css_animation_delay.'>';
$output .= '<span>'.wpb_js_remove_wpautop($content).'</span>';
$output .= '</h2>';

echo $output;

}
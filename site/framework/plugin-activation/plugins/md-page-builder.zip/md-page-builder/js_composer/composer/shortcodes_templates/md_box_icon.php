<?php

if(file_exists(get_template_directory().'/framework/shortcodes/templates/md_box_icon.php')){
  require_once (get_template_directory().'/framework/shortcodes/templates/md_box_icon.php');
}

else{

extract(shortcode_atts(array(
    'class' 		=> '',
    'id'			=> '',
    'css_animation' => '',
    'css_animation_delay' => '',
    'icon_position' => '',
    'icon'          => '',
    'icon_scheme'   => '',
    'icon_size'     => '',
    'icon_style'    => '',
    'icon_color'    => '',
    'icon_margin'   => '',
), $atts));


$animated = ($css_animation) ? 'animate' : '';
$css_animation_delay = ($css_animation) ? ' data-delay="'.$css_animation_delay.'"' : '';

$class  = setClass(array('md-box-icon', $animated, $css_animation, 'align-icon-'.$icon_position, 'size-'.$icon_size, 'type-'.$icon_style));
$id     = setId($id);
$style  = '';


$output = '<div'.$class.$id.$style.$css_animation_delay.'>';

$output .= '<div class="wrap-icon">';
$output .= do_shortcode('[md_icon icon="'.$icon.'" icon_scheme="'.$icon_scheme.'" icon_size="'.$icon_size.'" icon_style="'.$icon_style.'" icon_color="'.$icon_color.'" icon_margin="'.$icon_margin.'"]');
$output .= '</div>';

$output .= '<div class="box-text">'.wpb_js_remove_wpautop($content).'</div>';

$output .= '</div>';
$output .= '<div class="clearfix"></div>';

echo $output;

}
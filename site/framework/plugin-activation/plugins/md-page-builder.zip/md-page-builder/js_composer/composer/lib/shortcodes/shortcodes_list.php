<?php
/**
 *
 * MD Shortcodes Shortcodes List
 *
 */

if(file_exists(get_template_directory().'/framework/shortcodes/lib/md_shortcodes_list.php')){
  require_once (get_template_directory().'/framework/shortcodes/lib/md_shortcodes_list.php');
}

else{

$md_shortcodes['shortcodes_list'] = array(
  "name"            => __("Shortcodes List", "js_composer"),
  "base"            => "md_shortcodes_list",
  "content_element" => false,
  "modal"           => false,
  "show_settings_on_create"   => false,
);

}

vc_map( $md_shortcodes['shortcodes_list'] );

class WPBakeryShortCode_MD_Shortcodes_List extends WPBakeryShortCode {}
<?php
/**
 *
 * MD Shortcodes Raw JS
 *
 */

if(file_exists(get_template_directory().'/framework/shortcodes/lib/md_raw_js.php')){
  require_once (get_template_directory().'/framework/shortcodes/lib/md_raw_js.php');
}

else{


$md_shortcodes['md_raw_js'] = array(
  "name"            => __("Raw JS", "js_composer"),
  "base"            => "md_raw_js",
  "modal"           => false,
  "params"          => array(
    array(
      "type"        => "textarea",
      "heading"     => __("Text", "js_composer"),
      "param_name"  => "content",
      "value"       => "",
      "description" => __("Put your JS Here.", "js_composer")
    )
  )
);

}

vc_map($md_shortcodes['md_raw_js'] );

class WPBakeryShortCode_MD_Raw_js extends WPBakeryShortCode {}
<?php

if(file_exists(get_template_directory().'/framework/shortcodes/templates/md_counter.php')){
  require_once (get_template_directory().'/framework/shortcodes/templates/md_counter.php');
}

else{

extract(shortcode_atts(array(
    'class' 			=> '',
    'id' 				=> '',
    'css_animation' 	=> '',
    'css_animation_delay' 	=> '',
    'start_delay' 		=> '',
    'start' 			=> '',
    'end' 				=> '',
    'speed' 			=> 1000,
    'color' 			=> '',
), $atts));

$animated = ($css_animation) ? 'animate' : '';
$css_animation_delay = ($css_animation) ? ' data-delay="'.$css_animation_delay.'"' : '';

$class  = setClass(array('md-counter', $animated, $css_animation, $class));
$id 	= setId($id);

$output .= '<div'.$class.$id.$css_animation_delay.'>';
$output .= '<span class="number" data-delay="'.$start_delay.'" data-from="'.$start.'" data-to="'.$end.'" data-speed="'.$speed.'" style="color:'.$color.'">'.$start.'</span>';
$output .= wpb_js_remove_wpautop($content);
$output .= '</div>';

echo $output;

}

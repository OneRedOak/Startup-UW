<?php

if(file_exists(get_template_directory().'/framework/shortcodes/templates/md_single_image.php')){
  require_once (get_template_directory().'/framework/shortcodes/templates/md_single_image.php');
}

else{

extract(shortcode_atts(array(
    'class' 		=> '',
    'id' 			=> '',
    'css_animation' => '',
    'css_animation_delay' => '',
    'image'			=> '',
    'effect' 		=> '',
    'border' 		=> '',
    'border_color' 	=> '',
    'border_size' 	=> '',
    'href' 			=> '',
    'target' 		=> '',
), $atts));

$animated = ($css_animation) ? 'animate' : '';
$css_animation_delay = ($css_animation) ? ' data-delay="'.$css_animation_delay.'"' : '';

$class  = setClass(array('md-single-image', $animated, $css_animation, $class, $effect, $border));
$id     = setId($id);

$src    = wp_get_attachment_image_src( $image, 'full');
$alt    = ( get_post_meta($image, '_wp_attachment_image_alt', true) ) ? get_post_meta($image, '_wp_attachment_image_alt', true) : '';

$style  = ($border && $border_color && $border_size) ? ' style="border:'.$border_size.' solid '.$border_color.';"' : '';


$output = '<img src="'.$src[0].'"'.$class.$id.$style.$css_animation_delay.' alt="'.esc_attr($alt).'" />';
if($href){
	($target) ? $target = ' target="_blank"' : $target = '';
	$output = '<a href="'.$href.'"'.$target.'>'.$output.'</a>';
}

echo $output;

}
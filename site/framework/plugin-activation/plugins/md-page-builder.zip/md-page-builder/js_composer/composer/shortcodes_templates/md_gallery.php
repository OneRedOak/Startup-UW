<?php

if(file_exists(get_template_directory().'/framework/shortcodes/templates/md_gallery.php')){
  require_once (get_template_directory().'/framework/shortcodes/templates/md_gallery.php');
}

else{

extract(shortcode_atts(array(
    'class' 		=> '',
    'id' 			=> '',
    'css_animation' => '',
    'css_animation_delay' => '',
    'images'		=> '',
    'type'			=> '',
    'thumb'			=> '',
    'item_cols' 		=> '2',
    'item_cols_tablet' 	=> '6',
), $atts));


$animated = ($css_animation) ? 'animate' : '';
$css_animation_delay = ($css_animation) ? ' data-delay="'.$css_animation_delay.'"' : '';

$class  = setClass(array('md-gallery', 'md-gallery-'.$type, $animated, $css_animation, $class));
$id 	= setId($id);



switch($item_cols){
	case '1':
		$item_cols = 12;
	break;

	case '2':
		$item_cols = 6;
	break;

	case '3':
		$item_cols = 4;
	break;

	case '4':
		$item_cols = 3;
	break;

	case '6':
		$item_cols = 2;
	break;
}

switch($item_cols_tablet){
	case '1':
		$item_cols_tablet = 12;
	break;

	case '2':
		$item_cols_tablet = 6;
	break;

	case '3':
		$item_cols_tablet = 4;
	break;

	case '4':
		$item_cols_tablet = 3;
	break;

	case '6':
		$item_cols_tablet = 2;
	break;
}


$output = '<div'.$class.$id.$css_animation_delay.'>';
	
	if($type == 'lightbox')
	$output .= '<div class="row">';
		
		$images = explode(',', $images);

		if($type != 'slider'){
			foreach ($images as $image):
				$src_thumb    = wp_get_attachment_image_src( $image, 'square-1');
				$src_full    = wp_get_attachment_image_src( $image, 'full');
				$alt 	= ( get_post_meta($image, '_wp_attachment_image_alt', true) ) ? get_post_meta($image, '_wp_attachment_image_alt', true) : '';

				switch ($type){

					case 'lightbox':
						$output .= '<div class="item col-md-'.$item_cols.' col-sm-'.$item_cols_tablet.'">';
						$output .= '<div class="md-lightbox-thumb">';
						$output .= '<a href="'.$src_full[0].'" title="'.$alt.'">';
						$output .= '<img src="'.$src_thumb[0].'" alt="'.$alt.'" class="img-full-responsive">';
						$output .= '<span class="mask"><i class="icon-camera"></i></span>';
						$output .= '</a>';
						$output .= '</div>';
						$output .= '</div>';
					break;

					case 'stacked':
						$output .= '<img src="'.$src_full[0].'" alt="'.$alt.'" class="item img-full-responsive"  />';
					break;
				}

			endforeach;
		}

		else{
			$args = array(
				'gallery' => $images,
				'return'  => true
			);
			$output .= '<div class="flexslider">';
				$output .= '<ul class="slides">';
					foreach($args['gallery'] as $image):
						$src = wp_get_attachment_image_src( $image, 'full' );
						$output .= '<li><img src="'.$src[0].'" alt="" /></li>';
					endforeach;
				$output .= '</ul>';
			$output .= '</div>';
		}

	if($type == 'lightbox')
	$output .= '</div>';

$output .= '</div>';
$output .= '<div class="clearfix"></div>';

echo $output;

}
<?php
/**
 *
 * MD Shortcodes Clients
 *
 */

if(file_exists(get_template_directory().'/framework/shortcodes/lib/md_clients.php')){
  require_once (get_template_directory().'/framework/shortcodes/lib/md_clients.php');
}

else{

$md_shortcodes['md_clients'] = array(
  "name"            => __("Clients", "js_composer"),
  "base"            => "md_clients",
  "modal"           => true,
  "params"          => array(
    array(
      "type"        => "textarea_html",
      "heading"     => __("Content", "js_composer"),
      "param_name"  => "content",
      "disable_modal"  => true,
      "shortcode_btn"  => 'only',
      "shortcode"   => "md_clients",
      "value"       => ""
    ),
    array(
      "type"        => "custom",
      "param_name"  => "client",
      "name"        => "client",
    ),
    /*
    array(
      "type"        => "radio",
      "heading"     => __("Carousel", "js_composer"),
      "param_name"  => "carousel",
      "value"       => array(
        'Yes'       => 'carousel',
        'No'        => '',
      ),
      "default"     => "carousel"
    ),
    */
    $element_options['class'],
    $element_options['id'],
    $element_options['css_animation'],
    $element_options['css_animation_delay'],
  )
);

}

vc_map($md_shortcodes['md_clients']);

class WPBakeryShortCode_MD_Clients extends WPBakeryShortCode {}


if(file_exists(get_template_directory().'/framework/shortcodes/lib/md_client.php')){
  require_once (get_template_directory().'/framework/shortcodes/lib/md_client.php');
}

else{

$md_shortcodes['md_client'] = array(
  "name"            => __("Client", "js_composer"),
  "base"            => "md_client",
  "content_element" => false,
  "modal"           => false,
);

}

vc_map($md_shortcodes['md_client']);

class WPBakeryShortCode_MD_Client extends WPBakeryShortCode_MD_Clients {}
<?php
/**
 *
 * MD Shortcodes Social Share Classic
 *
 */

if(file_exists(get_template_directory().'/framework/shortcodes/lib/md_social_share_classic.php')){
  require_once (get_template_directory().'/framework/shortcodes/lib/md_social_share_classic.php');
}

else{

$md_shortcodes['md_social_share_classic'] = array(
  "name"            => __("Social Share Classic", "js_composer"),
  "base"            => "md_social_share_classic",
  "modal"           => true,
  "params"          => array(
    array(
      "type"        => "radio",
      "heading"     => __("Facebook", "js_composer"),
      "param_name"  => "facebook",
      "value"       => array(
        'Yes'       => 'yes',
        'No'        => 'no',
      ),
      "default"     => "yes"
    ),
    array(
      "type"        => "radio",
      "heading"     => __("Twitter", "js_composer"),
      "param_name"  => "twitter",
      "value"       => array(
        'Yes'       => 'yes',
        'No'        => 'no',
      ),
      "default"     => "yes"
    ),
    array(
      "type"        => "radio",
      "heading"     => __("Google Plus", "js_composer"),
      "param_name"  => "googleplus",
      "value"       => array(
        'Yes'       => 'yes',
        'No'        => 'no',
      ),
      "default"     => "yes"
    ),
    array(
      "type"        => "radio",
      "heading"     => __("Pinterest", "js_composer"),
      "param_name"  => "pinterest",
      "value"       => array(
        'Yes'       => 'yes',
        'No'        => 'no',
      ),
      "default"     => "yes"
    ),
    $element_options['class'],
    $element_options['id'],
    $element_options['css_animation'],
    $element_options['css_animation_delay'],
  )
);

}

vc_map( $md_shortcodes['md_social_share_classic'] );

class WPBakeryShortCode_MD_Social_Share_Classic extends WPBakeryShortCode {}


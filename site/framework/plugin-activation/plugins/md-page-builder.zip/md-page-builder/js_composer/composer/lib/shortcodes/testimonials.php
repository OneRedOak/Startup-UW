<?php
/**
 *
 * MD Shortcodes Testimonials
 *
 */

if(file_exists(get_template_directory().'/framework/shortcodes/lib/md_testimonials.php')){
  require_once (get_template_directory().'/framework/shortcodes/lib/md_testimonials.php');
}

else{

$md_shortcodes['md_testimonials'] = array(
  "name"            => __("Testimonials", "js_composer"),
  "base"            => "md_testimonials",
  "modal"           => true,
  "params"          => array(
    array(
      "type"        => "textarea_html",
      "heading"     => __("Content", "js_composer"),
      "param_name"  => "content",
      "disable_modal"  => true,
      "shortcode_btn"  => 'only',
      "shortcode"   => "md_testimonials",
      "value"       => ""
    ),
    array(
      "type"        => "radio",
      "heading"     => __("Carousel", "js_composer"),
      "param_name"  => "carousel",
      "value"       => array(
        'Yes'       => 'carousel',
        'No'        => 'no-carousel',
      ),
      "default"     => "carousel"
    ),
    array(
      "type"        => "custom",
      "param_name"  => "testimonial",
      "name"        => "testimonial",
    ),
    $element_options['class'],
    $element_options['id'],
    $element_options['css_animation'],
    $element_options['css_animation_delay'],
  )
);

}

vc_map($md_shortcodes['md_testimonials']);

class WPBakeryShortCode_MD_testimonials extends WPBakeryShortCode {}


if(file_exists(get_template_directory().'/framework/shortcodes/lib/md_testimonial.php')){
  require_once (get_template_directory().'/framework/shortcodes/lib/md_testimonial.php');
}

else{

$md_shortcodes['md_testimonial'] = array(
  "name"            => __("testimonial", "js_composer"),
  "base"            => "md_testimonial",
  "content_element" => false,
  "modal"           => false,
);

}

vc_map($md_shortcodes['md_testimonial']);

class WPBakeryShortCode_MD_Testimonial extends WPBakeryShortCode_MD_Testimonials {}
<?php
/**
 *
 * MD Shortcodes Single Image
 *
 */

if(file_exists(get_template_directory().'/framework/shortcodes/lib/md_single_image.php')){
  require_once (get_template_directory().'/framework/shortcodes/lib/md_single_image.php');
}

else{


$element_options['target']['param_name'] = 'single_image_target';
$md_shortcodes['md_single_image'] = array(
  "name"            => __("Single Image", "js_composer"),
  "base"            => "md_single_image",
  "modal"           => false,
  "params"          => array(
    array(
      "type"        => "attach_image",
      "heading"     => __("Image", "js_composer"),
      "param_name"  => "image",
      "description" => __("Select image from media library.", "js_composer")
    ),
    array(
      "type"        => "radio",
      "heading"     => __("Image Effect", "js_composer"),
      "param_name"  => "effect",
      "value"       => array(
        'No Effect' => '',
        'Round'     => 'image-round',
        'Circle'    => 'image-circle'
      ),
      "default"     => "",
      "description" => __("Select image effect. If circle use square image.", "js_composer")
    ),
    array(
      "type"        => "radio",
      "heading"     => __("Image Border", "js_composer"),
      "param_name"  => "border",
      "value"       => array(
        'No'        => '',
        'Yes'       => 'border'
      ),
      "default"     => "",
      "description" => __("Set image border.", "js_composer")
    ),
    array(
      "type"        => "colorpicker",
      "heading"     => __("Border Color", "js_composer"),
      "param_name"  => "border_color",
      "value"       => $theme_options['accent-color'],
      "description" => __("Set image border color (eg. #000000).", "js_composer"),
      "dependency"  => array('element' => "border", 'value' => 'border')
    ),
    array(
      "type"        => "textfield",
      "heading"     => __("Border Size", "js_composer"),
      "param_name"  => "border_size",
      "value"       => '5px',
      "description" => __("Set image border size (eg. 5px)", "js_composer"),
      "dependency"  => array('element' => "border", 'value' => 'border')
    ),
    array(
      "type"        => "textfield",
      "heading"     => __("Image link", "js_composer"),
      "param_name"  => "href",
      "description" => __("Enter url if you want this image to have link.", "js_composer")
    ),
    $element_options['target'],
    $element_options['class'],
    $element_options['id'],
    $element_options['css_animation'],
    $element_options['css_animation_delay'],
  )
);

}

vc_map( $md_shortcodes['md_single_image'] );

class WPBakeryShortCode_MD_Single_image extends WPBakeryShortCode {}

<?php
/**
 *
 * MD Shortcodes Button
 *
 */

if(file_exists(get_template_directory().'/framework/shortcodes/lib/md_button.php')){
  require_once (get_template_directory().'/framework/shortcodes/lib/md_button.php');
}

else{

$element_options['target']['param_name'] = 'button_target';
$element_options['icons_list']['dependency'] = array('element' => 'icon_btn', 'value' => 'with-icon');
$md_shortcodes['md_button'] = array(
  "name"            => __("Button", "js_composer"),
  "base"            => "md_button",
  "modal"           => true,
  "params"          => array(
    array(
      "type"        => "textfield",
      "heading"     => __("Text", "js_composer"),
      "param_name"  => "content",
      "value"       => ""
    ),
    array(
      "type"        => "textfield",
      "heading"     => __("Link URL", "js_composer"),
      "param_name"  => "href",
      "value"       => __("#", "js_composer"),
    ),
    $element_options['target'],
    array(
      "type"        => "radio",
      "heading"     => __("Size", "js_composer"),
      "param_name"  => "size",
      "value"       => array(
        __('Medium', "js_composer")   => "medium", 
        __('Small', "js_composer")    => "small", 
        __('Large', "js_composer")    => "large", 
      ),
      "default"     => 'medium',
    ),
    array(
      "type"        => "radio",
      "heading"     => __("Button Style", "js_composer"),
      "param_name"  => "fill",
      "value"       => array(
        __('Fill', "js_composer")  => "fill", 
        __('No Fill', "js_composer")  => "no-fill", 
      ),
      "default"     => "fill"
    ),
    array(
      "type"        => "radio",
      "heading"     => __("Color Scheme", "js_composer"),
      "param_name"  => "color_scheme",
      "value"       => array(
        __('Accent Color', "js_composer") => "accent", 
        __('Custom', "js_composer") => "custom", 
      ),
      "default"     => "accent"
    ),
    array(
      "type"        => "colorpicker",
      "heading"     => __("Main Color", "js_composer"),
      "param_name"  => "bgcolor",
      "value"       => $theme_options['accent-color'],
      "dependency"  => array('element' => 'color_scheme', 'value' => 'custom')
    ),
    array(
      "type"        => "colorpicker",
      "heading"     => __("Text Color", "js_composer"),
      "param_name"  => "color",
      "value"       => '#ffffff',
      "dependency"  => array('element' => 'color_scheme', 'value' => 'custom')
    ),
    array(
      "type"        => "colorpicker",
      "heading"     => __("Text Color Hover", "js_composer"),
      "param_name"  => "color_hover",
      "value"       => '#ffffff',
      "dependency"  => array('element' => 'color_scheme', 'value' => 'custom')
    ),
    array(
      "type"        => "radio",
      "heading"     => __("With Icon?", "js_composer"),
      "param_name"  => "icon_btn",
      "value"       => array(
        __('No', "js_composer") => "", 
        __('Yes', "js_composer") => "with-icon", 
      ),
      "default"     => ""
    ),
    $element_options['icons_list'],
    $element_options['class'],
    $element_options['id'],
    $element_options['css_animation'],
    $element_options['css_animation_delay'],
  )
);

}

vc_map( $md_shortcodes['md_button'] );

class WPBakeryShortCode_MD_Button extends WPBakeryShortCode {}


$element_options['icons_list']['dependency'] = null;

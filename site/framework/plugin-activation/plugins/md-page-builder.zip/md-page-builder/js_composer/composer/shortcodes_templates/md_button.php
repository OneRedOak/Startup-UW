<?php

if(file_exists(get_template_directory().'/framework/shortcodes/templates/md_button.php')){
  require_once (get_template_directory().'/framework/shortcodes/templates/md_button.php');
}

else{

extract(shortcode_atts(array(
    'class' 		=> '',
    'id' 			=> '',
    'css_animation' => '',
    'css_animation_delay' => '',
    'size'  		=> '',
    'href'          => '',
    'target'        => '',
    'fill'          => 'fill',
    'color_scheme'  => '',
    'bgcolor'       => '',
    'color'         => '',
    'color_hover'   => '',
    'icon_btn'      => '',
    'icon'          => ''
), $atts));

$animated = ($css_animation) ? 'animate' : '';
$css_animation_delay = ($css_animation) ? ' data-delay="'.$css_animation_delay.'"' : '';

$class  = setClass(array('md-button', $animated, $css_animation, $class, $color_scheme, $size, $fill, $icon_btn));
$id     = setId($id);
$target = ($target) ? ' target="_blank"' : '';


$style = '';
if($color_scheme == 'custom'){
    if($fill == 'fill'){
        $style = ' style="background-color:'.$bgcolor.'; color:'.$color.';"';
   }
    else{
        $style = ' style="border-color:'.$bgcolor.'; color:'.$color.';"';
    }
}

$data_hover = ' data-hover="'.$bgcolor.'|'.$color_hover.'"';


$output .= '<a href="'.$href.'"'.$class.$id.$target.$style.$data_hover.$css_animation_delay.'>';
if($icon_btn == 'with-icon' && $icon){
    $icon_color = ($fill == 'no-fill' && $color_scheme == 'custom') ? ' style="color:'.$color.'"' : '';
    $output .= '<span class="btn-icon"><i class="md-icon '.$icon.'"'.$icon_color.'></i></span>';
}

$output .= '<span class="lbl">'.wpb_js_remove_wpautop($content).'</span>';
$output .= '</a>';

echo $output;

}

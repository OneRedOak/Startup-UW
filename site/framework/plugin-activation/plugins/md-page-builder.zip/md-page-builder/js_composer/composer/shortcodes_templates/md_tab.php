<?php

if(file_exists(get_template_directory().'/framework/shortcodes/templates/md_tab.php')){
  require_once (get_template_directory().'/framework/shortcodes/templates/md_tab.php');
}

else{

extract(shortcode_atts(array(
	'title' => ''
), $atts));

/*
if(isset($GLOBALS['tab_bg'])){
	$custom_style = ' style="background-color:'.$GLOBALS['tab_bg'].'"';
}
else if(isset($GLOBALS['tab_border'])){
	$custom_style = ' style="border-color:'.$GLOBALS['tab_border'].'"'; 
}
else $custom_style = '';

$custom_link_color = (isset($GLOBALS['tab_border'])) ? ' style="color:'.$GLOBALS['tab_border'].'"' : ''; 
*/

$uid = uniqid();

if($GLOBALS['tabs'] == 'nav'){
	$output = '<li><a href="#'.$uid.'" data-toggle="tab">'.$title.'</a></li>';
}

else{
	$output = '<div class="tab-pane">'.wpb_js_remove_wpautop($content).'</div>';
}

echo $output;

}
<?php

if(file_exists(get_template_directory().'/framework/shortcodes/templates/md_box.php')){
  require_once (get_template_directory().'/framework/shortcodes/templates/md_box.php');
}

else{

extract(shortcode_atts(array(
    'class' 		=> '',
    'id'			=> '',
    'css_animation' => '',
    'css_animation_delay' => '',
    'fill' 			=> '',
    'color_scheme' 	=> '',
    'custom_color' 	=> '',
    'border' 		=> '',
), $atts));

$animated = ($css_animation) ? 'animate' : '';
$css_animation_delay = ($css_animation) ? ' data-delay="'.$css_animation_delay.'"' : '';

$class  = setClass(array('md-box', $animated, $css_animation, $class, $color_scheme, $fill, $border));
$id 	= setId($id);



if($custom_color && $color_scheme == 'custom' && $fill == 'fill')
$style =  ' style="background-color:'.$custom_color.'"'; 

else if($custom_color && $color_scheme == 'custom' && $fill == 'no-fill')
$style =  ' style="border-color:'.$custom_color.'"'; 

else $style = '';

$output .= '<div'.$class.$id.$style.$css_animation_delay.'>';
$output .= '<div class="text">';
$output .= wpb_js_remove_wpautop($content);
$output .= '</div>';
$output .= '</div>';

echo $output;

}
<?php
/**
 * WPBakery Visual Composer shortcodes Colum Inner
 *
 * @package WPBakeryVisualComposer
 *
 */

class WPBakeryShortCode_VC_Column_Inner extends WPBakeryShortCode_VC_Column {}

vc_map( array(
  "name"                          => __("Column", "js_composer"),
  "base"                          => "vc_column_inner",
  "class"                         => "",
  "wrapper_class"                 => "",
  "controls"                      => "full",
  "allowed_container_element"     => false,
  "content_element"               => false,
  "is_container"                  => true,
  "params"                        => array(
    $element_options['text_align'],
    $element_options['class'],
    $element_options['id'],
    $element_options['css_animation'],
    $element_options['css_animation_delay'],
  ),
  "js_view"                       => 'VcColumnView'
) );
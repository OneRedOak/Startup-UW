<?php

if(file_exists(get_template_directory().'/framework/shortcodes/templates/md_heading.php')){
  require_once (get_template_directory().'/framework/shortcodes/templates/md_heading.php');
}

else{

extract(shortcode_atts(array(
    'class' 		=> '',
    'id' 			=> '',
    'css_animation' => '',
    'css_animation_delay' => '',
    'kind'          => '',
    'text_align'    => '',
    'special_font'  => '',
    'color_scheme'  => '',
    'color'         => '',
    'size'          => '',
    'fontsize'      => '',
    'lineheight'    => '',
), $atts));

$animated = ($css_animation) ? 'animate' : '';
$css_animation_delay = ($css_animation) ? ' data-delay="'.$css_animation_delay.'"' : '';

$class  = setClass(array('md-heading', $animated, $css_animation, $class, $text_align, $special_font, $color_scheme));
$id     = setId($id);
$css_animation  = setAnimation($css_animation);


$style = '';
$s_color = '';
$s_fontsize = '';
$s_lineheight = '';
if($color_scheme == 'custom'){
    $s_color = 'color:'.$color.';';
}

if($size == 'custom'){
    $s_fontsize = 'font-size:'.$fontsize.';';
    $s_lineheight = 'line-height:'.$lineheight.';';
}

$style = ' style="'.$s_color.$s_fontsize.$s_lineheight.'"';


$output .= '<'.$kind.$class.$id.$css_animation_delay.$style.'>';
$output .= wpb_js_remove_wpautop($content);
$output .= '</'.$kind.'>';

echo $output;

}

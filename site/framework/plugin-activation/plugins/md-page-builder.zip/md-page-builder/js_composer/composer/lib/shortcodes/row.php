<?php
/**
 * WPBakery Visual Composer shortcodes Row
 *
 * @package WPBakeryVisualComposer
 *
 */

class WPBakeryShortCode_VC_Row extends WPBakeryShortCode {
    protected $predefined_atts = array(
        'class' => ''
    );

    /* This returs block controls
   ---------------------------------------------------------- */
    public function getColumnControls($controls, $extended_css = '') {
        global $vc_row_layouts;
        $controls_start = '<div class="controls controls_row clearfix">';
        $controls_end = '</div>';

        $right_part_start = '';//'<div class="controls_right">';
        $right_part_end = '';//'</div>';

        //Create columns
        $controls_center_start = '<span class="vc_row_layouts">';
        $controls_layout = '';
        foreach($vc_row_layouts as $layout) {
            $controls_layout .= '<a class="set_columns '.$layout['icon_class'].'" data-cells="'.$layout['cells'].'" data-cells-mask="'.$layout['mask'].'" title="'.$layout['title'].'"></a> ';
        }
        $controls_layout .= '<a class="set_columns custom_columns" data-cells="custom" data-cells-mask="custom" title="'.__('Custom layout', 'js_composer').'"><i class="icon-plus"></i></a> ';
        $controls_move = ' <a class="column_move" href="#" title="'.__('Drag row to reorder', 'js_composer').'"><i class="icon-move"></i></a>';
        $controls_delete = '<a class="column_delete" href="#" title="'.__('Delete this row', 'js_composer').'"><i class="icon-trash"></i></a>';
        $controls_edit = ' <a class="column_edit" href="#" title="'.__('Edit this row', 'js_composer').'"><i class="icon-pencil"></i></a>';
        $controls_clone = ' <a class="column_clone" href="#" title="'.__('Clone this row', 'js_composer').'"><i class="icon-copy"></i></a>';
        $controls_hide = ' <a class="column_hide hide_row" href="#" title="'.__('Hide this row', 'js_composer').'"><i class="icon-eye-open"></i></a>';
        $controls_center_end = '</span>';

        $row_edit_clone_delete = '<span class="vc_row_edit_clone_delete">';
        $row_edit_clone_delete .= $controls_delete . $controls_clone . $controls_edit . $controls_hide;
        $row_edit_clone_delete .= '</span>';

        //$column_controls_full =  $controls_start. $controls_move . $controls_center_start . $controls_layout . $controls_delete . $controls_clone . $controls_edit . $controls_center_end . $controls_end;
        $column_controls_full =  $controls_start. $controls_move . $controls_center_start . $controls_layout . $controls_center_end . $row_edit_clone_delete . $controls_end;
        $column_controls_full =  $controls_start. $controls_move  . $row_edit_clone_delete . $controls_end;

        return $column_controls_full;
    }

    public function contentAdmin($atts, $content = null) {
        $width = $class = '';
        extract(shortcode_atts($this->predefined_atts, $atts));

        $output = '';

        $column_controls = $this->getColumnControls($this->settings('controls'));

        for ( $i=0; $i < count($width); $i++ ) {
            $output .= '<div'.$this->customAdminBockParams().' data-element_type="'.$this->settings["base"].'" class="wpb_'.$this->settings['base'].' wpb_sortable">';
            $output .= str_replace("%column_size%", 1, $column_controls);
            $output .= '<div class="wpb_element_wrapper">';
            $output .= '<div class="vc_row-fluid wpb_row_container vc_container_for_children">';
            if($content=='' && !empty($this->settings["default_content_in_template"])) {
                $output .= do_shortcode( shortcode_unautop($this->settings["default_content_in_template"]) );
            } else {
                $output .= do_shortcode( shortcode_unautop($content) );

            }
            $output .= '</div>';
            if ( isset($this->settings['params']) ) {
                $inner = '';
                foreach ($this->settings['params'] as $param) {
                    $param_value = isset($$param['param_name']) ? $$param['param_name'] : '';
                    if ( is_array($param_value)) {
                        // Get first element from the array
                        reset($param_value);
                        $first_key = key($param_value);
                        $param_value = $param_value[$first_key];
                    }
                    $inner .= $this->singleParamHtmlHolder($param, $param_value);
                }
                $output .= $inner;
            }
            $output .= '</div>';
            $output .= '</div>';
        }

        return $output;
    }
    public function customAdminBockParams() {
        return '';
    }
}



global $element_options;

/*
$element_options['video_src']['dependency'] = array('element' => "bg", 'value' => array('custom-bgvideo'));
$element_options['video_loop']['dependency'] = array('element' => "bg", 'value' => array('custom-bgvideo'));
$element_options['video_autoplay']['dependency'] = array('element' => "bg", 'value' => array('custom-bgvideo'));
$element_options['video_controls']['dependency'] = array('element' => "bg", 'value' => array('custom-bgvideo'));
$element_options['video_preload']['dependency'] = array('element' => "bg", 'value' => array('custom-bgvideo'));
$element_options['video_poster']['dependency'] = array('element' => "bg", 'value' => array('custom-bgvideo'));
$element_options['video_mask']['dependency'] = array('element' => "bg", 'value' => array('custom-bgvideo'));
*/

vc_map( array(
  "name"            => __("Section", "js_composer"),
  "base"            => "vc_row",
  "is_container"    => true,
  "content_element" => false,
  "show_settings_on_create" => false,
  "category"        => __('Content', 'js_composer'),
  "params"          => array(
    array(
      "type"        => "dropdown",
      "heading"     => __("Container Width", "js_composer"),
      "param_name"  => "container_type",
      "value"       => array(
        __('Default', "js_composer")  => "", 
        __('Full Width - Fixed Content', "js_composer")   => "section-full-width",
        __('Full Width - Full Content', "js_composer")   => "section-full-width-all"
      ),
      "description" => __("Choose Layout Mode. Fixed width have 1140px Container. Full Width have 100% Container.", "js_composer")
    ),
    array(
      "type"        => "dropdown",
      "heading"     => __("Padding", "js_composer"),
      "param_name"  => "padding",
      "value"       => array(
        __('No Padding', "js_composer")   => "no-padding", 
        __('Small', "js_composer")        => "small",
        __('Medium', "js_composer")       => "medium", 
        __('Large', "js_composer")        => "large",
        __('Custom', "js_composer")       => "custom",
      ),
      "description" => __("Choose Padding Top / Bottom.", "js_composer")
    ),
    array(
      "type"        => "textfield",
      "heading"     => __("Custom Padding Top", "js_composer"),
      "param_name"  => "padding_top",
      "description" => __("Set custom padding top (eg. 60px).", "js_composer"),
      "dependency"  => array('element' => "padding", 'value' => array('custom'))
    ),
    array(
      "type"        => "textfield",
      "heading"     => __("Custom Padding Bottom", "js_composer"),
      "param_name"  => "padding_bottom",
      "description" => __("Set custom padding bottom (eg. 60px).", "js_composer"),
      "dependency"  => array('element' => "padding", 'value' => array('custom'))
    ),
    array(
      "type"        => "textfield",
      "heading"     => __("Fixed Height", "js_composer"),
      "param_name"  => "fixed_height",
      "description" => __("Set fixed height. (eg. 400px).", "js_composer"),
    ),
    array(
      "type"        => "dropdown",
      "heading"     => __("Background", "js_composer"),
      "param_name"  => "bgtype",
      "value"       => array(
        __('Default', "js_composer")  => "", 
        __('Accent Color', "js_composer")  => "accent", 
        __('Custom Color', "js_composer") => "bgcolor",
        __('Image', "js_composer") => "bgimage",
        __('Video', "js_composer") => "bgvideo",
      ),
      "description" => __("Choose Background.", "js_composer")
    ),
    array(
      "type"        => "textfield",
      "heading"     => __("Video MP4 Format", "js_composer"),
      "param_name"  => "video_mp4",
      "description" => __("Set Url MP4 Video.", "js_composer"),
      "value"       => "",
      "dependency"  => array('element' => "bgtype", 'value' => array('bgvideo'))
    ),
    array(
      "type"        => "textfield",
      "heading"     => __("Video WEBM Format", "js_composer"),
      "param_name"  => "video_webm",
      "description" => __("Set Url WEBM Video.", "js_composer"),
      "value"       => "",
      "dependency"  => array('element' => "bgtype", 'value' => array('bgvideo'))
    ),
    array(
      "type"        => "textfield",
      "heading"     => __("Video OGV Format", "js_composer"),
      "param_name"  => "video_ogv",
      "description" => __("Set Url OGV Video.", "js_composer"),
      "value"       => "",
      "dependency"  => array('element' => "bgtype", 'value' => array('bgvideo'))
    ),
    array(
      "type"        => "attach_image",
      "heading"     => __("Video Poster Image", "js_composer"),
      "param_name"  => "video_poster",
      "description" => __("Set Poster Image.", "js_composer"),
      "value"       => "",
      "dependency"  => array('element' => "bgtype", 'value' => array('bgvideo'))
    ),
    array(
      "type"        => "colorpicker",
      "class"       => "color",
      "heading"     => __("Custom Background Color", "js_composer"),
      "param_name"  => "bgcolor",
      "description" => __("Set custom background color.", "js_composer"),
      "value"       => "#ffffff",
      "dependency"  => array('element' => "bgtype", 'value' => array('bgcolor'))
    ),
    array(
      "type"        => "attach_image",
      "heading"     => __("Custom Background Image", "js_composer"),
      "param_name"  => "bgimage",
      "description" => __("Set custom background image.", "js_composer"),
      "dependency"  => array('element' => "bgtype", 'value' => array('bgimage'))
    ),
    array(
      "type"        => "dropdown",
      "heading"     => __("Background Parallax", "js_composer"),
      "param_name"  => "bgparallax",
      "value"       => array(
        __('Yes', "js_composer")          => 'bg-parallax', 
        __('No', "js_composer")           => 'bg-no-parallax'
      ),
      "description" => __("Enable / Disable Background Parallax.", "js_composer"),
      "dependency"  => array('element' => "bgtype", 'value' => array('bgimage'))
    ),
    array(
      "type"        => "dropdown",
      "heading"     => __("Background Mask", "js_composer"),
      "param_name"  => "bgmask",
      "value"       => array(
        __('No', "js_composer")           => '',
        __('Yes', "js_composer")          => 'yes', 
      ),
      "default"     => '',
      "description" => __("Enable / Disable Background Mask.", "js_composer")
    ),
    array(
      "type"        => "colorpicker",
      "heading"     => __("Background Mask Color", "js_composer"),
      "param_name"  => "bgmask_color",
      "value"       => "#000000",
      "description" => __("Choose Background Mask Color.", "js_composer"),
      "dependency"  => array('element' => "bgmask", 'value' => 'yes')
    ),
    array(
      "type"        => "dropdown",
      "heading"     => __("Background Image Position", "js_composer"),
      "param_name"  => "bgimage_position",
      "value"       => array(
        __('Top Left', "js_composer")     => 'top left', 
        __('Top Center', "js_composer")   => 'top center', 
        __('Top Right', "js_composer")    => 'top right', 
        __('Center Left', "js_composer")     => 'center left', 
        __('Center Center', "js_composer")   => 'center center', 
        __('Center Right', "js_composer")    => 'center right', 
        __('Bottom Left', "js_composer")     => 'bottom left', 
        __('Bottom Center', "js_composer")   => 'bottom center', 
        __('Bottom Right', "js_composer")    => 'bottom right', 
      ),
      "description" => __("Set Background Image Position.", "js_composer"),
      "dependency"  => array('element' => "bgparallax", 'value' => array('bg-no-parallax'))
    ),
    array(
      "type"        => "dropdown",
      "heading"     => __("Background Image Repeat", "js_composer"),
      "param_name"  => "bgimage_repeat",
      "value"       => array(
        __('No Repeat', "js_composer")     => 'no-repeat', 
        __('Repeat', "js_composer")        => 'repeat', 
        __('Repeat Horizontally', "js_composer")  => 'repeat-x', 
        __('Repeat Vertically', "js_composer")  => 'repeat-y', 
        ),
      "description" => __("Set Background Position.", "js_composer"),
      "dependency"  => array('element' => "bgparallax", 'value' => array('bg-no-parallax'))
    ),
    array(
      "type"        => "dropdown",
      "heading"     => __("Background Size", "js_composer"),
      "param_name"  => "bgimage_size",
      "value"       => array(
        __('Auto', "js_composer")    => '', 
        __('Cover', "js_composer")      => 'cover', 
        __('Contain', "js_composer")    => 'contain'
      ),
      "description" => __("Set Background Size.", "js_composer"),
      "dependency"  => array('element' => "bgparallax", 'value' => array('bg-no-parallax'))
    ),
    array(
      "type"        => "dropdown",
      "heading"     => __("Background Attachment", "js_composer"),
      "param_name"  => "bgimage_attach",
      "value"       => array(
        __('Scroll', "js_composer")     => 'scroll', 
        __('Fixed', "js_composer")      => 'fixed'
      ),
      "description" => __("Set Background Attachment.", "js_composer"),
      "dependency"  => array('element' => "bgparallax", 'value' => array('bg-no-parallax'))
    ),

    $element_options['class'],
    $element_options['id'],
    $element_options['css_animation'],
    $element_options['css_animation_delay'],
  ),
  "js_view" => 'VcRowView'
) );
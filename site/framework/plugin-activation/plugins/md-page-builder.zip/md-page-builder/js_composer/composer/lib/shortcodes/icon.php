<?php
/**
 *
 * MD Shortcodes Icon
 *
 */

if(file_exists(get_template_directory().'/framework/shortcodes/lib/md_icon.php')){
  require_once (get_template_directory().'/framework/shortcodes/lib/md_icon.php');
}

else{

$element_options['icon_color']['dependency']['element'] = 'icon_scheme';
$md_shortcodes['md_icon'] = array(
  "name"            => __("Icon", "js_composer"),
  "base"            => "md_icon",
  "modal"           => true,
  "params"          => array(
    $element_options['icons_list'],
    $element_options['icon_size'],
    $element_options['icon_style'],
    $element_options['icon_scheme'],
    $element_options['icon_color'],
    $element_options['icon_margin'],
    $element_options['class'],
    $element_options['id'],
    $element_options['css_animation'],
    $element_options['css_animation_delay'],
  )
);

}

vc_map( $md_shortcodes['md_icon'] );

class WPBakeryShortCode_MD_Icon extends WPBakeryShortCode {}

$element_options['icon_color']['dependency']['element'] = null;

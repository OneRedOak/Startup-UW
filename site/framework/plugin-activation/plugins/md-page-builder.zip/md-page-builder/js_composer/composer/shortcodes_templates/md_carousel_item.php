<?php

if(file_exists(get_template_directory().'/framework/shortcodes/templates/md_carousel_item.php')){
  require_once (get_template_directory().'/framework/shortcodes/templates/md_carousel_item.php');
}

else{

extract(shortcode_atts(array(
), $atts));

$output = '<div class="item">';
$output .= wpb_js_remove_wpautop($content);
$output .= '</div>';

echo $output;

}
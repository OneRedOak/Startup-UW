<?php

if(file_exists(get_template_directory().'/framework/shortcodes/templates/md_lightbox_map.php')){
  require_once (get_template_directory().'/framework/shortcodes/templates/md_lightbox_map.php');
}

else{

extract(shortcode_atts(array(
    'class' 		=> '',
    'id' 			=> '',
    'css_animation' => '',
    'css_animation_delay' => '',
    'size'			=> '',
    'thumb'			=> '',
    'map'			=> '',
), $atts));

$animated = ($css_animation) ? 'animate' : '';
$css_animation_delay = ($css_animation) ? ' data-delay="'.$css_animation_delay.'"' : '';

$class  = setClass(array('md-lightbox-thumb', $animated, $css_animation, $class));
$id 	= setId($id);

$src    = wp_get_attachment_image_src( $thumb, $size);
$alt 	= ( get_post_meta($thumb, '_wp_attachment_image_alt', true) ) ? get_post_meta($thumb, '_wp_attachment_image_alt', true) : '';

$icon	= 'icon-map-marker';


$output = '<div'.$class.$id.$css_animation_delay.'>';
$output .= '<a href="'.$map.'" class="lightbox-map">';
$output .= '<span class="mask"><i class="'.$icon.'"></i></span>';
$output .= '<img src="'.$src[0].'" alt="'.$alt.'" class="isive" />';
$output .= '</a>';
$output .= '</div>';

echo $output;

}
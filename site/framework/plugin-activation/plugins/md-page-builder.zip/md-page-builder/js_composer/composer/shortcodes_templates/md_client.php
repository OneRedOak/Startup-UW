<?php

if(file_exists(get_template_directory().'/framework/shortcodes/templates/md_client.php')){
  require_once (get_template_directory().'/framework/shortcodes/templates/md_client.php');
}

else{
	
extract(shortcode_atts(array(
	'image' => '',
	'href' 	=> ''
), $atts));


$image = wp_get_attachment_image_src( $image, 'large');

$output = '<div class="md-client">';

if($href)
	$output .= '<a href="'.$href.'" target="_blank"><img src="'.$image[0].'" alt="" class="" /></a>';
else
	$output .= '<img src="'.$image[0].'" alt="" class="" />';
$output .= '</div>';

echo $output;

}
<?php
/**
 *
 * MD Shortcodes Caroseul
 *
 */

if(file_exists(get_template_directory().'/framework/shortcodes/lib/md_carousel.php')){
  require_once (get_template_directory().'/framework/shortcodes/lib/md_carousel.php');
}

else{

$md_shortcodes['md_carousel'] = array(
  "name"            => __("Carousel Custom", "js_composer"),
  "base"            => "md_carousel",
  "modal"           => true,
  "params"          => array(
    array(
      "type"        => "textarea_html",
      "heading"     => __("Content", "js_composer"),
      "param_name"  => "content",
      "disable_modal" => true,
      "shortcode_btn"  => 'only',
      "shortcode"   => "md_carousel",
      "value"       => "",
      "description" => __("Highlight content for edit.", "js_composer"),
    ),
    array(
      "type"        => "radio",
      "heading"     => __("Items Wide", "js_composer"),
      "param_name"  => "items",
      "value"       => array(
		"1" => "1", 
		"2" => "2", 
		"3" => "3", 
		"4" => "4", 
		"5" => "5", 
		"6" => "6", 
      ),
      "default"     => "3"
    ),
    array(
      "type"        => "radio",
      "heading"     => __("Items Desktop", "js_composer"),
      "param_name"  => "items_desktop",
      "value"       => array(
		"1" => "1", 
		"2" => "2", 
		"3" => "3", 
		"4" => "4", 
		"5" => "5", 
		"6" => "6", 
      ),
      "default"     => "3"
    ),
    array(
      "type"        => "radio",
      "heading"     => __("Items Tablet", "js_composer"),
      "param_name"  => "items_tablet",
      "value"       => array(
		"1" => "1", 
		"2" => "2", 
		"3" => "3", 
		"4" => "4", 
		"5" => "5", 
		"6" => "6", 
      ),
      "default"     => "2"
    ),
    array(
      "type"        => "radio",
      "heading"     => __("Items Mobile", "js_composer"),
      "param_name"  => "items_mobile",
      "value"       => array(
		"1" => "1", 
		"2" => "2", 
		"3" => "3", 
		"4" => "4", 
		"5" => "5", 
		"6" => "6", 
      ),
      "default"     => "1"
    ),
    array(
      "type"        => "custom",
      "param_name"  => "carousel",
      "name"        => "carousel",
    ),
    $element_options['class'],
    $element_options['id'],
    $element_options['css_animation'],
    $element_options['css_animation_delay'],
  )
);

}

vc_map($md_shortcodes['md_carousel']);

class WPBakeryShortCode_MD_Carousel extends WPBakeryShortCode {}


if(file_exists(get_template_directory().'/framework/shortcodes/lib/md_carousel_item.php')){
  require_once (get_template_directory().'/framework/shortcodes/lib/md_carousel_item.php');
}

else{

$md_shortcodes['md_carousel_item'] = array(
  "name"            => __("Carousel Item", "js_composer"),
  "base"            => "md_carousel_item",
  "content_element" => false,
  "modal"           => false,
);

}

vc_map($md_shortcodes['md_carousel_item']);

class WPBakeryShortCode_MD_Carousel_Item extends WPBakeryShortCode_MD_Carousel {}

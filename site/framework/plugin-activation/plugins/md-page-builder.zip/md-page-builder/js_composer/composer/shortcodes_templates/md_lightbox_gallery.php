<?php

if(file_exists(get_template_directory().'/framework/shortcodes/templates/md_lightbox_gallery.php')){
  require_once (get_template_directory().'/framework/shortcodes/templates/md_lightbox_gallery.php');
}

else{

extract(shortcode_atts(array(
    'class' 		=> '',
    'id' 			=> '',
    'css_animation' => '',
    'css_animation_delay' => '',
    'thumb'			=> '',
    'images'		=> '',
    'effect'		=> '',
), $atts));

$animated = ($css_animation) ? 'animate' : '';
$css_animation_delay = ($css_animation) ? ' data-delay="'.$css_animation_delay.'"' : '';

$class  = setClass(array('md-lightbox-thumb', $animated, $css_animation, $class));
$id 	= setId($id);


$src = array();
$src[] = wp_get_attachment_image_src( $thumb, 'thumb');
$alt = ( get_post_meta($thumb, '_wp_attachment_image_alt', true) ) ? get_post_meta($thumb, '_wp_attachment_image_alt', true) : '';

$images = explode(',', $images);

foreach($images as $image):
	$src[] = wp_get_attachment_image_src( $image, 'wide-1');	
endforeach;



$output = '<div class="md-gallery-lightbox">';
	$output .= '<div'.$class.$id.$css_animation_delay.'>';
		$output .= '<a href="#" class="lightbox-image" data-effect="'.$effect.'">';
			$output .= '<span class="mask"><i class="icon-camera"></i></span>';
			$output .= '<img src="'.$src[0][0].'" alt="'.$alt.'" />';
		$output .= '</a>';
	
	$output .= '</div>';
$output .= '</div>';
echo $output;

}
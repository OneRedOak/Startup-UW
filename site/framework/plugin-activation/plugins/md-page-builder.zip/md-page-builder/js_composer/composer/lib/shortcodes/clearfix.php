<?php
/**
 *
 * MD Shortcodes Clearfix
 *
 */

if(file_exists(get_template_directory().'/framework/shortcodes/lib/md_clearfix.php')){
  require_once (get_template_directory().'/framework/shortcodes/lib/md_clearfix.php');
}

else{

$md_shortcodes['md_clearfix'] = array(
  "name" 						=> __("Clearfix", "js_composer"),
  "base" 						=> "md_clearfix",
  "modal"        				=> true,
  "show_settings_on_create" 	=> false,
);

}

vc_map( $md_shortcodes['md_clearfix'] );

class WPBakeryShortCode_MD_Clearfix extends WPBakeryShortCode {}

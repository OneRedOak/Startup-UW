<?php
/**
 *
 * MD Shortcodes Team Grid
 *
 */


if(file_exists(get_template_directory().'/framework/shortcodes/lib/md_team_grid.php')){
  require_once (get_template_directory().'/framework/shortcodes/lib/md_team_grid.php');
}

else{

$md_shortcodes['md_team_grid'] = array(
  "name"            => __("Team Grid", "js_composer"),
  "base"            => "md_team_grid",
  "modal"           => true,
  "params"          => array(
    array(
      "type"        => "radio",
      "heading"     => __("Preview Size", "js_composer"),
      "param_name"  => "size",
      "value"       => array(
            __('Default', "js_composer") => "post-image", 
            __('Square', "js_composer") => "square-1", 
            __('Wide', "js_composer")  => "wide-1", 
            __('Tall', "js_composer")  => "tall-1", 
      ),
      "default"     => "post-image",
      "description" => __("Select preview size.", "js_composer")
    ),
    $element_options['posts_per_page'],
    $element_options['items_cols'],
    $element_options['items_cols_tablet'],
    $element_options['order_by'],
    $element_options['order'],
    $element_options['class'],
    $element_options['id'],
    $element_options['css_animation'],
    $element_options['css_animation_delay'],
  )
);

}

vc_map( $md_shortcodes['md_team_grid'] );

class WPBakeryShortCode_MD_Team_grid extends WPBakeryShortCode {}

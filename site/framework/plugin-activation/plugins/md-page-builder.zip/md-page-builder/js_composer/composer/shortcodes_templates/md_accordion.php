<?php

if(file_exists(get_template_directory().'/framework/shortcodes/templates/md_accordion.php')){
  require_once (get_template_directory().'/framework/shortcodes/templates/md_accordion.php');
}

else{

extract(shortcode_atts(array(
	'title' => ''
), $atts));

if(isset($GLOBALS['acc_bg'])){
	$custom_style = ' style="background-color:'.$GLOBALS['acc_bg'].'"';
}
else if(isset($GLOBALS['acc_border'])){
	$custom_style = ' style="border-color:'.$GLOBALS['acc_border'].'"'; 
}
else $custom_style = '';

$custom_link_color = (isset($GLOBALS['acc_border'])) ? ' style="color:'.$GLOBALS['acc_border'].'"' : ''; 

$uid = 'tab_'.uniqid();

$output = '<div class="panel">';

$output .= '<div class="panel-heading"'.$custom_style.'>';
$output .= '<h4 class="panel-title">';
$output .= '<a data-toggle="collapse" href="#'.$uid.'" class="collapsed"'.$custom_link_color.'>'.$title.' <i class="icon-minus minimize"></i><i class="icon-plus expand"></i></a>';
$output .= '</h4>';
$output .= '</div>';

$output .= '<div id="'.$uid.'" class="panel-collapse collapse">';
$output .= '<div class="panel-body">'.wpb_js_remove_wpautop($content).'</div>';
$output .= '</div>';

$output .= '</div>';

echo $output;

}
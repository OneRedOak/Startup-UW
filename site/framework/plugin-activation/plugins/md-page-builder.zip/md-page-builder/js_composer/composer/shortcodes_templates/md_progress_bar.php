<?php

if(file_exists(get_template_directory().'/framework/shortcodes/templates/md_progress_bar.php')){
  require_once (get_template_directory().'/framework/shortcodes/templates/md_progress_bar.php');
}

else{

extract(shortcode_atts(array(
    'class' 		=> '',
    'id' 			=> '',
    'css_animation' => '',
    'css_animation_delay' => '',
    'start_animated' => '',
    'percent'		=> '',
    'color_scheme'	=> '',
    'bgcolor'		=> '',
    'color'			=> ''
), $atts));

$animated = ($css_animation) ? 'animate' : '';
$css_animation_delay = ($css_animation) ? ' data-delay="'.$css_animation_delay.'"' : '';

$class  = setClass(array('md-progress-bar', $animated, $css_animation, $class, $color_scheme, $start_animated));
$id     = setId($id);

$width = ($start_animated == 'start-animated') ? '' : 'width:"'.$percent.'%"';


$style = ($width) ? ' style="width:'.$percent.'%;" ' : '';
$style = ($color_scheme == 'custom') ? ' style="background-color:'.$bgcolor.'; color:'.$color.';'.$width.'";' : $style;

$output .= '<div'.$class.$id.$css_animation_delay.'>';
$output .= '<span'.$style.' data-percent="'.$percent.'">'.wpb_js_remove_wpautop($content).' - '.$percent.'%</span>';
$output .= '</div>';

echo $output;

}

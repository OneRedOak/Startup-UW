<?php
/**
 *
 * MD Shortcodes Special Heading
 *
 */

if(file_exists(get_template_directory().'/framework/shortcodes/lib/md_special_heading.php')){
  require_once (get_template_directory().'/framework/shortcodes/lib/md_special_heading.php');
}

else{


$md_shortcodes['md_special_heading'] = array(
  "name"                => __("Special Heading", "js_composer"),
  "base"                => "md_special_heading",
  "modal"               => true,
  "params"              => array(
    array(
          "type"        => "textfield",
          "heading"     => __("Text", "js_composer"),
          "param_name"  => "content",
          "value"       => ""
    ),
    array(
          "type"        => "radio",
          "heading"     => __("Text Align", "js_composer"),
          "param_name"  => "align",
          "value"       => array(
            __('Default', "js_composer")    => "", 
            __('Center', "js_composer")     => "textaligncenter", 
            __('Left', "js_composer")       => "textalignleft", 
            __('Right', "js_composer")      => "textalignright", 
          ),
          "default"     => "",
          "description" => __("Select heading alignament.", "js_composer")
    ),
    array(
      "type"        => "radio",
      "heading"     => __("Special Font", "js_composer"),
      "param_name"  => "special_font",
      "value"       => array(
        __('No', "js_composer") => "", 
        __('Yes', "js_composer") => "special-font", 
      ),
      "default"     => ""
    ),
    $element_options['class'],
    $element_options['id'],
    $element_options['css_animation'],
    $element_options['css_animation_delay'],
  )
);

}

vc_map( $md_shortcodes['md_special_heading'] );

class WPBakeryShortCode_MD_Special_heading extends WPBakeryShortCode {}
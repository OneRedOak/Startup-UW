<?php
/**
 *
 * MD Shortcodes Counter
 *
 */


if(file_exists(get_template_directory().'/framework/shortcodes/lib/md_counter.php')){
  require_once (get_template_directory().'/framework/shortcodes/lib/md_counter.php');
}

else{

$md_shortcodes['md_counter'] = array(
  "name"            => __("Counter", "js_composer"),
  "base"            => "md_counter",
  "modal"           => true,
  "params"          => array(
    array(
      "type"        => "textarea_html",
      "heading"     => __("Label", "js_composer"),
      "param_name"  => "content",
      "value"       => ""
    ),
    array(
      "type"        => "textfield",
      "heading"     => __("Start Delay", "js_composer"),
      "param_name"  => "start_delay",
      "value"       => "0",
      "description" => __("Insert start delay in ms (eg: 200).", "js_composer"),
    ),
    array(
      "type"        => "textfield",
      "heading"     => __("Start", "js_composer"),
      "param_name"  => "start",
      "value"       => "0",
      "description" => __("Insert start number.", "js_composer"),
    ),
    array(
      "type"        => "textfield",
      "heading"     => __("End", "js_composer"),
      "param_name"  => "end",
      "value"       => "100",
      "description" => __("Insert End number.", "js_composer"),
   ),
    array(
      "type"        => "textfield",
      "heading"     => __("Speed", "js_composer"),
      "param_name"  => "speed",
      "value"       => "1000",
      "description" => __("Insert Speed time.", "js_composer"),
   ),
    array(
      "type"        => "colorpicker",
      "heading"     => __("Number Color", "js_composer"),
      "param_name"  => "color",
      "value"       => $theme_options['accent-color']
    ),
    $element_options['class'],
    $element_options['id'],
    $element_options['css_animation'],
    $element_options['css_animation_delay'],
  )
);

}

vc_map( $md_shortcodes['md_counter'] );

class WPBakeryShortCode_MD_Counter extends WPBakeryShortCode {}
<?php

if(file_exists(get_template_directory().'/framework/shortcodes/templates/md_social_share.php')){
  require_once (get_template_directory().'/framework/shortcodes/templates/md_social_share.php');
}

else{

extract(shortcode_atts(array(
    'class' 			=> '',
    'id' 				=> '',
    'css_animation' => '',
    'css_animation_delay' => '',
    'facebook' 			=> '',
    'twitter' 			=> '',
    'googleplus' 		=> '',
    'pinterest' 			=> ''

), $atts));

$animated = ($css_animation) ? 'animate' : '';
$css_animation_delay = ($css_animation) ? ' data-delay="'.$css_animation_delay.'"' : '';

$class  = setClass(array('md-social-share', $animated, $css_animation, $class));
$id 	= setId($id);

$share_count = new shareCount("http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]");

$output .= '<div'.$class.$id.$css_animation_delay.'>';
if($facebook == 'yes')
$output .= '<div class="item"><a href="#" id="share-facebook"><i class="icon-facebook"></i><span class="social">Facebook</span></a><span class="count">'.$share_count->get_fb().'</span></div>';

if($twitter == 'yes')
$output .= '<div class="item"><a href="#" id="share-twitter"><i class="icon-twitter"></i><span class="social">Twitter</span></a><span class="count">'.$share_count->get_tweets().'</span></div>';

if($googleplus == 'yes')
$output .= '<div class="item"><a href="#" id="share-google"><i class="icon-google-plus"></i><span class="social">Google+</span></a><span class="count">'.$share_count->get_plusones().'</span></div>';

if($pinterest == 'yes')
$output .= '<div class="item"><a href="#" id="share-pinterest"><i class="icon-pinterest"></i><span class="social">Pinterest</span></a><span class="count">'.$share_count->get_pinterest().'</span></div>';

$output .= '</div>';

echo $output;

}

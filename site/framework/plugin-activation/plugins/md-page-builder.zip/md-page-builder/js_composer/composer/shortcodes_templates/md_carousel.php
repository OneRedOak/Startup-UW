<?php

if(file_exists(get_template_directory().'/framework/shortcodes/templates/md_carousel.php')){
  require_once (get_template_directory().'/framework/shortcodes/templates/md_carousel.php');
}

else{

extract(shortcode_atts(array(
    'class' 		=> '',
    'id' 			=> '',
    'css_animation' => '',
    'css_animation_delay' => '',
    'items' => '',
    'items_desktop' => '',
    'items_tablet' => '',
    'items_mobile' => '',
), $atts));

$animated = ($css_animation) ? 'animate' : '';
$css_animation_delay = ($css_animation) ? ' data-delay="'.$css_animation_delay.'"' : '';

$class  = setClass(array('md-carousel', $animated, $css_animation, $class));
$id 	= setId($id);

$output = '<div'.$class.$id.$css_animation_delay.' data-items="'.$items.'" data-items-desktop="'.$items_desktop.'" data-items-tablet="'.$items_tablet.'" data-items-mobile="'.$items_mobile.'">';
$output .= wpb_js_remove_wpautop($content);
$output .= '</div>';

echo $output;

}
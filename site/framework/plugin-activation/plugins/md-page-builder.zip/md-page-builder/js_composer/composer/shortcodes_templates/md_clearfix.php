<?php

if(file_exists(get_template_directory().'/framework/shortcodes/templates/md_clearfix.php')){
  require_once (get_template_directory().'/framework/shortcodes/templates/md_clearfix.php');
}

else{
$output = '<div class="clearfix"></div>';

echo $output;
}

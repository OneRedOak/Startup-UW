<?php

if(file_exists(get_template_directory().'/framework/shortcodes/templates/md_revslider.php')){
  require_once (get_template_directory().'/framework/shortcodes/templates/md_revslider.php');
}

else{

extract(shortcode_atts(array(
    'alias' => ''
), $atts));


echo do_shortcode( "[rev_slider ".$alias."]" );

}


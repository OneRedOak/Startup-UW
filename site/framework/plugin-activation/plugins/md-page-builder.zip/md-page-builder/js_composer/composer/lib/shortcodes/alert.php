<?php
/**
 *
 * MD Shortcodes Alert
 *
 */

if(file_exists(get_template_directory().'/framework/shortcodes/lib/md_alert.php')){
  require_once (get_template_directory().'/framework/shortcodes/lib/md_alert.php');
}

else{

$md_shortcodes['md_alert'] = array(
  "name"            => __("Alert", "js_composer"),
  "base"            => "md_alert",
  "modal"           => true,
  "params"          => array(
    array(
      "type"        => "textarea_html",
      "heading"     => __("Text", "js_composer"),
      "param_name"  => "content",
      "value"       => ""
    ),
    array(
      "type"        => "radio",
      "heading"     => __("Type", "js_composer"),
      "param_name"  => "kind",
      "value"       => array(
            __('Info', "js_composer")     => "info", 
            __('Warning', "js_composer")  => "warning", 
            __('Success', "js_composer")  => "success", 
            __('Error', "js_composer")    => "error", 
      ),
      "default"     => "info",
      "description" => __("Select alert type.", "js_composer"),
    ),
    $element_options['class'],
    $element_options['id'],
    $element_options['css_animation'],
    $element_options['css_animation_delay'],
  )
);

}

vc_map( $md_shortcodes['md_alert'] );

class WPBakeryShortCode_MD_Alert extends WPBakeryShortCode {}
<?php

if(file_exists(get_template_directory().'/framework/shortcodes/templates/md_text.php')){
  require_once (get_template_directory().'/framework/shortcodes/templates/md_text.php');
}

else{

extract(shortcode_atts(array(
    'class' 		=> '',
    'id' 			=> '',
    'css_animation' => '',
    'css_animation_delay' => '',
    'text_align' 	=> '',
), $atts));

$animated = ($css_animation) ? 'animate' : '';
$css_animation_delay = ($css_animation) ? ' data-delay="'.$css_animation_delay.'"' : '';

$class  = setClass(array('md-text-block', $animated, $css_animation, $class, $text_align));
$id 	= setId($id);

$output .= '<div'.$class.$id.$css_animation_delay.'>';
$output .=  wpb_js_remove_wpautop($content);
$output .= '</div>';
$output .= '<div class="clearfix"></div>';

echo $output;

}

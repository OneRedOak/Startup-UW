<?php
/**
 *
 * MD Shortcodes Progress Circular
 *
 */

if(file_exists(get_template_directory().'/framework/shortcodes/lib/md_progress_circular.php')){
  require_once (get_template_directory().'/framework/shortcodes/lib/md_progress_circular.php');
}

else{


$md_shortcodes['md_progress_circular'] =  array(
  "name"            => __("Progress Circular", "js_composer"),
  "base"            => "md_progress_circular",
  "modal"           => true,
  "params"          => array(
    array(
      "type"        => "textfield",
      "heading"     => __("Percent", "js_composer"),
      "param_name"  => "percent",
      "description" => __("Set the percent value (0-100 without %).", "js_composer"),
      "value"       => "",
    ),
     array(
      "type"        => "textfield",
      "heading"     => __("Label", "js_composer"),
      "param_name"  => "content",
      "value"       => "",
      "description" => __("Set the label.", "js_composer")
   ),
     array(
      "type"        => "colorpicker",
      "heading"     => __("Label Color", "js_composer"),
      "param_name"  => "label_color",
      "description" => __("Set the label color.", "js_composer"),
      "value"       => "#bbbbbb",
    ),
    array(
      "type"        => "radio",
      "heading"     => __("Color Scheme", "js_composer"),
      "param_name"  => "color_scheme",
      "value"       => array(
        __('Default Theme', "js_composer") => "", 
        __('Accent Color', "js_composer") => "accent", 
        __('Custom', "js_composer") => "custom", 
      ),
      "default"     => "default"
    ),
    array(
      "type"        => "colorpicker",
      "heading"     => __("Percent Color", "js_composer"),
      "param_name"  => "percent_color",
      "description" => __("Set the percent label color.", "js_composer"),
      "value"       => $theme_options['accent-color'],
      "dependency"  => array('element' => 'color_scheme', 'value' => 'custom')
    ),
    array(
      "type"        => "colorpicker",
      "heading"     => __("Bar Color", "js_composer"),
      "param_name"  => "barcolor",
      "description" => __("The color of the circular bar.", "js_composer"),
      "value"       => "#bbbbbb",
      "dependency"  => array('element' => 'color_scheme', 'value' => 'custom')
    ),
    array(
      "type"        => "colorpicker",
      "heading"     => __("Track Color", "js_composer"),
      "param_name"  => "trackcolor",
      "description" => __("The color of the track for the bar.", "js_composer"),
      "value"       => $theme_options['accent-color'],
      "dependency"  => array('element' => 'color_scheme', 'value' => 'custom')
    ),
    array(
      "type"        => "radio",
      "heading"     => __("Line Cap", "js_composer"),
      "param_name"  => "linecap",
      "description" => __("Defines how the ending of the bar line looks like. ", "js_composer"),
      "value"       => array(
        __('Butt', "js_composer")   => "butt", 
        __('Round', "js_composer")  => "round", 
        __('Square', "js_composer") => "square", 
      ),
      "default"     => "butt"
    ),
    array(
      "type"        => "textfield",
      "heading"     => __("Line Width", "js_composer"),
      "param_name"  => "linewidth",
      "description" => __("Width of the bar line in px.", "js_composer"),
      "value"       => "24"
    ),
    array(
      "type"        => "textfield",
      "heading"     => __("Chart Size", "js_composer"),
      "param_name"  => "size",
      "description" => __("Size of the pie chart in px. It will always be a square.", "js_composer"),
      "value"       => "220"
    ),
    array(
      "type"        => "textfield",
      "heading"     => __("Animate", "js_composer"),
      "param_name"  => "animate",
      "description" => __("Time in milliseconds for a eased animation of the bar growing, or false to deactivate.", "js_composer"),
      "value"       => "1000"
    ),
    $element_options['class'],
    $element_options['id'],
    $element_options['css_animation'],
    $element_options['css_animation_delay'],
  )
);

}

vc_map( $md_shortcodes['md_progress_circular'] );

class WPBakeryShortCode_MD_Progress_Circular extends WPBakeryShortCode {}
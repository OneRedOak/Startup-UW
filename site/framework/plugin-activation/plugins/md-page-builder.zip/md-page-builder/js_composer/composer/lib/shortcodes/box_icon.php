<?php
/**
 *
 * MD Shortcodes Box Icon
 *
 */

if(file_exists(get_template_directory().'/framework/shortcodes/lib/md_box_icon.php')){
  require_once (get_template_directory().'/framework/shortcodes/lib/md_box_icon.php');
}

else{

$md_shortcodes['md_box_icon'] = array(
  "name"            => __("Box Icon", "js_composer"),
  "base"            => "md_box_icon",
  "modal"           => true,
  "params"          => array(
    array(
      "type"        => "textarea_html",
      "heading"     => __("Text", "js_composer"),
      "param_name"  => "content",
      "value"       => ""
    ),
    array(
      "type"        => "radio",
      "heading"     => __("Icon Position", "js_composer"),
      "param_name"  => "icon_position",
      "value"       => array(
        __('Top', "js_composer")   => "top", 
        __('Left', "js_composer")    => "left", 
        __('Right', "js_composer")    => "right", 
      ),
      "default"     => 'top',
    ),
    $element_options['icons_list'],
    $element_options['icon_size'],
    $element_options['icon_style'],
    $element_options['icon_scheme'],
    $element_options['icon_color'],
    $element_options['icon_margin'],
    $element_options['id'],
    $element_options['css_animation'],
    $element_options['css_animation_delay'],
  )
);

}

vc_map( $md_shortcodes['md_box_icon'] );

class WPBakeryShortCode_MD_Box_Icon extends WPBakeryShortCode {}
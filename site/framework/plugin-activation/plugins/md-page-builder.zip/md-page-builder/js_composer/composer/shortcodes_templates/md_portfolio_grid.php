<?php

if(file_exists(get_template_directory().'/framework/shortcodes/templates/md_portfolio_grid.php')){
  require_once (get_template_directory().'/framework/shortcodes/templates/md_portfolio_grid.php');
}

else{

extract(shortcode_atts(array(
    'class'				=> '',
    'id' 				=> '',
    'css_animation' => '',
    'css_animation_delay' => '',
    'filter' 			=> '',
    'carousel' 			=> '',
    'kind' 				=> '',
    'size' 				=> '',
    'item_cols' 		=> '4',
    'item_cols_tablet' 	=> '6',
	'posts_per_page'	=> '-1',
    'order' 			=> 'DESC',
    'orderby'		 	=> 'date'
), $atts));

$animated = ($css_animation) ? 'animate' : '';
$css_animation_delay = ($css_animation) ? ' data-delay="'.$css_animation_delay.'"' : '';

$carousel = ($filter == 'filter') ? '' : $carousel;

$class  = setClass(array('md-portfolio-grid', $animated, $css_animation, $class, $filter, $carousel));
$id 	= setId($id);


if($kind == 'wall'){
	$i_class  = 'item wall item-'.$item_cols.' item-tablet-'.$item_cols_tablet;
}
else{
	switch($item_cols){
		case '1':
			$item_cols = 12;
		break;

		case '2':
			$item_cols = 6;
		break;

		case '3':
			$item_cols = 4;
		break;

		case '4':
			$item_cols = 3;
		break;

		case '6':
			$item_cols = 2;
		break;
	}

	switch($item_cols_tablet){
		case '1':
			$item_cols_tablet = 12;
		break;

		case '2':
			$item_cols_tablet = 6;
		break;

		case '3':
			$item_cols_tablet = 4;
		break;

		case '4':
			$item_cols_tablet = 3;
		break;

		case '6':
			$item_cols_tablet = 2;
		break;
	}
	$i_class  = 'item block col-md-'.$item_cols.' col-sm-'.$item_cols_tablet;
}

$output = '';

if($filter == 'filter'){
	$args = array(
		'taxonomy' => 'portfolio-category',
		'type'	   => 'custom_post_type'
	);
	$categories = get_categories($args); 

	$output .= '<div class="md-portfolio-filter">';
			$output .= '<a href="#" data-filter="*" class="active">ALL</a>';
		foreach($categories as $category):

			$output .= '<a href="#" data-filter=".'.$category->slug.'">'.$category->name.'</a>';

		endforeach;
	$output .= '</div>';
}

$args = array(
	'post_type'			=> 'portfolio',
	'posts_per_page'	=> $posts_per_page,
	'order'				=> $order,
	'orderby'			=> $orderby,
);
$items = get_posts( $args );

$output .= '<div'.$class.$id.$css_animation_delay.' data-items-desktop="'.$item_cols.'" data-items-tablet="'.$item_cols_tablet.'">';
	foreach($items as $item):
		$item_meta = get_post_custom( $item->ID );

		$item_cats = wp_get_post_terms($item->ID, 'portfolio-category');
		$s_class = '';
		foreach($item_cats as $item_cat):
			$s_class .= ' '.$item_cat->slug;
		endforeach;

		$return = '';
		$return .= '<div'.setClass(array($i_class, $s_class)).'>';


			$image = wp_get_attachment_image_src( $item_meta['portfolio_preview_thumb'][0], $size.'-thumb');
			$image_alt = get_post_meta( $item_meta['portfolio_preview_thumb'][0], '_wp_attachment_image_alt', true);
			$image_open = wp_get_attachment_image_src( $item_meta['portfolio_preview_thumb'][0], 'large');
			
			$return .= '<div class="portfolio-image">';
				$return .= '<img src="'.$image[0].'" alt="'.esc_attr($image_alt).'" />';
				$return .= '<div class="over">';


					$return .= '<a href="'.$image_open[0].'" title="'.get_the_title($item->ID).'" class="lightbox-image" data-effect="mfp-move-horizontal"><i class="md-icon icon-fullscreen"></i></a>';
					$return .= '<a href="'.get_permalink($item->ID).'" title="'.get_the_title($item->ID).'"><i class="md-icon icon-link"></i></a>';
				$return .= '</div>';
			$return .= '</div>';

			$return .= '<div class="portfolio-content">';
				$return .= '<h4 class="portfolio-name"><a href="'.get_permalink($item->ID).'" title="'.esc_attr(get_the_title($item->ID)).'">'.get_the_title($item->ID).'</a></h4>';
				$return .= '<div class="portfolio-text">'.wpb_js_remove_wpautop($item_meta['portfolio_preview_text'][0]).'</div>';
			$return .= '</div>';


		$return .= '</div>';

		$output .= $return;
	endforeach;


$output .= '</div>';
	if($kind == 'block'){
		$output = '<div class="row">'.$output.'</div>';
	}
$output .= '<div class="clearfix"></div>';

echo $output;

}
<?php
/**
 *
 * MD Shortcodes Lighbox Video
 *
 */

if(file_exists(get_template_directory().'/framework/shortcodes/lib/md_lightbox_video.php')){
  require_once (get_template_directory().'/framework/shortcodes/lib/md_lightbox_video.php');
}

else{


$md_shortcodes['md_lightbox_video'] = array(
  "name"            => __("Lightbox Video", "js_composer"),
  "base"            => "md_lightbox_video",
  "modal"           => false,
  "params"          => array(
    array(
      "type"        => "attach_image",
      "heading"     => __("Thumb", "js_composer"),
      "param_name"  => "thumb",
      "description" => __("Choose your thumb.", "js_composer")
    ),
    array(
      "type"        => "textfield",
      "heading"     => __("Lightbox Video Url", "js_composer"),
      "param_name"  => "video",
      "description" => __("Insert the complete url of the video (Youtube/Vimeo).", "js_composer")
    ),
    array(
      "type"        => "radio",
      "heading"     => __("Preview Size", "js_composer"),
      "param_name"  => "size",
      "value"       => array(
            __('Default', "js_composer") => "post-image", 
            __('Square', "js_composer") => "square-1", 
            __('Wide', "js_composer")  => "wide-1", 
            __('Tall', "js_composer")  => "tall-1", 
      ),
      "default"     => "post-image",
      "description" => __("Select preview size.", "js_composer")
    ),
    $element_options['class'],
    $element_options['id'],
    $element_options['css_animation'],
    $element_options['css_animation_delay'],
  )
);

}

vc_map( $md_shortcodes['md_lightbox_video'] );

class WPBakeryShortCode_MD_Lightbox_Video extends WPBakeryShortCode {}
<?php

if(file_exists(get_template_directory().'/framework/shortcodes/templates/md_team_grid.php')){
  require_once (get_template_directory().'/framework/shortcodes/templates/md_team_grid.php');
}

else{

extract(shortcode_atts(array(
    'class'				=> '',
    'id' 				=> '',
    'css_animation' => '',
    'css_animation_delay' => '',
    'size'		 		=> '',
    'item_cols' 		=> '4',
    'item_cols_tablet' 	=> '6',
	'posts_per_page'	=> '-1',
    'order' 			=> 'DESC',
    'orderby'		 	=> 'date'
), $atts));

$animated = ($css_animation) ? 'animate' : '';
$css_animation_delay = ($css_animation) ? ' data-delay="'.$css_animation_delay.'"' : '';

$class  = setClass(array('md-team-grid', $animated, $css_animation, $class));
$id 	= setId($id);




switch($item_cols){
	case '1':
		$item_cols = 12;
	break;

	case '2':
		$item_cols = 6;
	break;

	case '3':
		$item_cols = 4;
	break;

	case '4':
		$item_cols = 3;
	break;

	case '5':
		$item_cols = 2;
	break;
}

switch($item_cols_tablet){
	case '1':
		$item_cols_tablet = 12;
	break;

	case '2':
		$item_cols_tablet = 6;
	break;

	case '3':
		$item_cols_tablet = 4;
	break;

	case '4':
		$item_cols_tablet = 3;
	break;

	case '5':
		$item_cols_tablet = 2;
	break;
}
$item_class  = setClass(array('item', 'col-md-'.$item_cols, 'col-sm-'.$item_cols_tablet));


$args = array(
	'post_type'			=> 'team',
	'posts_per_page'	=> $posts_per_page,
	'order'				=> $order,
	'orderby'			=> $orderby,
);
$items = get_posts( $args );


$output = '<div'.$class.$id.$css_animation_delay.'>';
	$output .= '<div class="row">';
	
	foreach($items as $item):
		$item_meta = get_post_custom( $item->ID );
		$image = wp_get_attachment_image_src( $item_meta['team_thumb'][0], $size.'-thumb');
		$image_alt = get_post_meta( $item_meta['team_thumb'][0], '_wp_attachment_image_alt', true);

		$return = '';
		$return .= '<div'.$item_class.'>';
			
			$return .= '<div class="team-image">';
				$return .= '<img src="'.$image[0].'" alt="'.esc_attr($image_alt).'" />';
			$return .= '</div>';
			
			$return .= '<div class="team-content">';
				$return .= '<h2 class="team-name">'.$item_meta['team_name'][0].'</h2>';
				$return .= '<span class="team-role">'.$item_meta['team_role'][0].'</span>';
				$return .= '<div class="team-text">'.wpb_js_remove_wpautop($item_meta['team_text'][0]).'</div>';
			$return .= '</div>';

			$return .= '<div class="team-social">';
				if(isset($item_meta['team_email']) && $item_meta['team_email'][0] != '')
				$return .= '<a href="mailto:'.$item_meta['team_email'][0].'" target="_blank" class="social-email"><i class="md-icon icon-1x icon-envelope-alt"></i></a>';

				if(isset($item_meta['team_website']) && $item_meta['team_website'][0] != '')
				$return .= '<a href="'.$item_meta['team_website'][0].'" target="_blank" class="social-website"><i class="md-icon icon-1x icon-home"></i></a>';

				$socials = array('facebook', 'twitter', 'google-plus', 'instagram', 'youtube', 'dribbble', 'skype', 'linkedin', 'foursquare', 'github');

				foreach ($socials as $social):

					if(isset($item_meta['team_'.$social]) && $item_meta['team_'.$social][0] != ''){
						$return .= '<a href="'.$item_meta['team_'.$social][0].'" target="_blank" class="social-'.$social.'"><i class="md-icon icon-1x icon-'.$social.'"></i></a>';
					}

				endforeach;
			$return .= '</div>';
		$return .= '</div>';

		$output .= $return;
	endforeach;

	$output .= '</div>';
$output .= '</div>';
$output .= '<div class="clearfix"></div>';


echo $output;

}
<?php

if(file_exists(get_template_directory().'/framework/shortcodes/templates/md_testimonial.php')){
  require_once (get_template_directory().'/framework/shortcodes/templates/md_testimonial.php');
}

else{

extract(shortcode_atts(array(
	'image' => '',
	'name' => ''
), $atts));


$image = wp_get_attachment_image_src( $image, 'thumb');

$output = '<div class="md-testimonial">';
$output .= '<div class="testimonial-content">';
$output .= '<span class="testimonial">'.$name.'</span>';
$output .= wpb_js_remove_wpautop($content);
$output .= '<img src="'.$image[0].'" alt="'.esc_attr($name).' " class="testimonial-image" />';
$output .= '</div>';
$output .= '</div>'; 

echo $output;

}
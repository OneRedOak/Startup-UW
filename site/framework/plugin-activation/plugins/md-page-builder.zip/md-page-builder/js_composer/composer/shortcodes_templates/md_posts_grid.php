<?php

if(file_exists(get_template_directory().'/framework/shortcodes/templates/md_posts_grid.php')){
  require_once (get_template_directory().'/framework/shortcodes/templates/md_posts_grid.php');
}

else{

extract(shortcode_atts(array(
    'class'				=> '',
    'id' 				=> '',
    'css_animation' => '',
    'css_animation_delay' => '',
    'carousel' 			=> '',
    'size' 				=> '',
    'item_cols' 		=> '4',
    'item_cols_tablet' 	=> '6',
	'posts_per_page'	=> '-1',
    'order' 			=> 'DESC',
    'orderby'		 	=> 'date'
), $atts));

$animated = ($css_animation) ? 'animate' : '';
$css_animation_delay = ($css_animation) ? ' data-delay="'.$css_animation_delay.'"' : '';

$class  = setClass(array('md-posts-grid', $animated, $css_animation, $class, $carousel));
$id 	= setId($id);


switch($item_cols){
	case '1':
		$item_cols = 12;
	break;

	case '2':
		$item_cols = 6;
	break;

	case '3':
		$item_cols = 4;
	break;

	case '4':
		$item_cols = 3;
	break;

	case '6':
		$item_cols = 2;
	break;
}

switch($item_cols_tablet){
	case '1':
		$item_cols_tablet = 12;
	break;

	case '2':
		$item_cols_tablet = 6;
	break;

	case '3':
		$item_cols_tablet = 4;
	break;

	case '4':
		$item_cols_tablet = 3;
	break;

	case '6':
		$item_cols_tablet = 2;
	break;
}
$i_class  = setClass(array('md-post item col-md-'.$item_cols.' col-sm-'.$item_cols_tablet));

$output = '<div class="row">';


$args = array(
	'post_type'			=> 'post',
	'posts_per_page'	=> $posts_per_page,
	'order'				=> $order,
	'orderby'			=> $orderby,
	'tax_query' => array(
		array(
			'taxonomy' => 'post_format',
			'field' => 'slug',
			'terms' => 'post-format-quote',
			'operator' => 'NOT IN'
		)
	)
);
$items = query_posts( $args );

$output .= '<div'.$class.$id.$css_animation_delay.'>';
	if(have_posts()) : while(have_posts()) : the_post();
		$post_meta = get_post_custom();
		$return = '<article'.$i_class.' id="post-'.get_the_id().'">';

			$post_thumb = get_the_post_thumbnail(get_the_id(), $size.'-thumb');

			switch( get_post_format()){
				case 'audio':
					$post_icon = 'icon-music';
				break;

				case 'video':
					$post_icon = 'icon-facetime-video';
				break;

				case 'gallery':
					$post_icon = 'icon-picture';
				break;

				case 'link':
					$post_icon = 'icon-link';
				break;

				case 'image':
					$post_thumb = wp_get_attachment_image_src( get_post_meta( get_the_id(), 'post_image', true ), $size.'-thumb' );
					$post_thumb_alt = ( get_post_meta($post_thumb, '_wp_attachment_image_alt', true) ) ? get_post_meta($post_thumb, '_wp_attachment_image_alt', true) : '';
					$post_thumb = '<img src="'.$post_thumb[0].'" alt="'.$post_thumb_alt.'" />';
					$post_icon = 'icon-picture';
				break;

				default:
					$post_icon = 'icon-link';
				break;
			}
			
			$return .= '<div class="post-thumb"><a href="'.get_permalink().'" title="'.esc_attr(get_the_title(get_the_id() )).'"><span class="over"><i class="md-icon icon-circled icon-2x '.$post_icon.'"></i></span>'.$post_thumb.'</a></div>';

			$return .= '<h2 class="entry-title"><a href="'.get_permalink().'" title="'.esc_attr(get_the_title(get_the_id() )).'">'.get_the_title(get_the_id() ).'</a></h2>';

			$return .= '<div class="entry-content">'.get_the_excerpt().'</div>';

			$comments_output = '';
			$num_comments = get_comments_number(); 

			if ( comments_open() ) {
				if ( $num_comments == 0 ) {
					$comments = __('0 Comments', MD_THEME_NAME);
				} elseif ( $num_comments > 1 ) {
					$comments = $num_comments . __(' Comments', MD_THEME_NAME);
				} else {
					$comments = __('1 Comment', MD_THEME_NAME);
				}
				$comments_output .= '<a href="' . get_comments_link() .'">'. $comments.'</a>';
			}

			$return .= '
				<div class="entry-meta entry-header">
					<span class="date"><i class="icon-calendar"></i>'.get_the_time( get_option('date_format') ).'</span>
					<span class="comments"><i class="icon-comment"></i>'.$comments_output.'</span>
				</div>';

		$return .= '</article>';
		$output .= $return;
	endwhile; endif; 
	wp_reset_query();
$output .= '</div>';
$output .= '</div>';
$output .= '<div class="clearfix"></div>';

echo $output;

}
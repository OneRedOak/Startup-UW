<?php

if(file_exists(get_template_directory().'/framework/shortcodes/templates/md_twitter_feed.php')){
  require_once (get_template_directory().'/framework/shortcodes/templates/md_twitter_feed.php');
}

else{

extract(shortcode_atts(array(
    'class' 		=> '',
    'id' 			=> '',
    'css_animation' => '',
    'css_animation_delay' => '',
    'carousel' 		=> '',
    'color' 		=> '',
    'user' 			=> '',
    'tweets' 		=> ''
), $atts));

$animated = ($css_animation) ? 'animate' : '';
$css_animation_delay = ($css_animation) ? ' data-delay="'.$css_animation_delay.'"' : '';

$class  = setClass(array('md-twitter-feed', $animated, $css_animation, $class, $carousel));
$id 	= setId($id);

$output .= '<div'.$class.$id.$css_animation_delay.'>';
$tweets = getTweets($tweets, $user);
	foreach($tweets as $tweet):
	  $output .= '
	  		<div class="item">
				<span class="tweet-text"><h4 style="color:'.$color.'">' . TwitterFilter($tweet['text']) . '</h4></span>
				<span class="tweet-time"><h6><a href="https://twitter.com/' . $user . '/status/' . $tweet['id_str'] . '" style="color:'.$color.'" target="_blank">' . date('j F o \a\t g:i A', strtotime($tweet['created_at'])) . '</a></h6></span>
			</div>';
	endforeach;
$output .=  wpb_js_remove_wpautop($content);
$output .= '</div>';

echo $output;

}
<?php

if(file_exists(get_template_directory().'/framework/shortcodes/templates/md_callout.php')){
  require_once (get_template_directory().'/framework/shortcodes/templates/md_callout.php');
}

else{

extract(shortcode_atts(array(
    'class' 		=> '',
    'id' 			=> '',
    'css_animation' => '',
    'css_animation_delay' => '',
    'text_align' 	=> '',
    'font_size' 	=> '40px',
), $atts));

$animated = ($css_animation) ? 'animate' : '';
$css_animation_delay = ($css_animation) ? ' data-delay="'.$css_animation_delay.'"' : '';

$class  = setClass(array('md-callout', $animated, $css_animation, $class, $text_align));
$id 	= setId($id);

$output .= '<div'.$class.$id.$css_animation_delay.' style="font-size:'.$font_size.';">';
$output .=  wpb_js_remove_wpautop($content);
$output .= '</div>';

echo $output;

}
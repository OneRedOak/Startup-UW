<?php
/**
 *
 * MD Shortcodes Lighbox Gallery
 *
 */

if(file_exists(get_template_directory().'/framework/shortcodes/lib/md_lightbox_gallery.php')){
  require_once (get_template_directory().'/framework/shortcodes/lib/md_lightbox_gallery.php');
}

else{


$md_shortcodes['md_lightbox_gallery'] = array(
  "name"            => __("Lightbox Gallery", "js_composer"),
  "base"            => "md_lightbox_gallery",
  "modal"           => false,
  "params"          => array(
    array(
      "type"        => "attach_image",
      "heading"     => __("Thumb", "js_composer"),
      "param_name"  => "thumb",
      "description" => __("Choose your thumb.", "js_composer")
    ),
    array(
      "type"        => "attach_images",
      "heading"     => __("Gallery Images", "js_composer"),
      "param_name"  => "images",
      "description" => __("Choose your lightbox Images.", "js_composer")
    ),
    array(
      "type"        => "dropdown",
      "heading"     => __("Open Effect", "js_composer"),
      "param_name"  => "effect",
      "value"       => array(
        'Move Horizontal' => 'mfp-move-horizontal',
        'Move From Top' => 'mfp-move-from-top',
        'Zoom In'   => 'mfp-zoom-in',
        'Zoom Out'  => 'mfp-zoom-out',
        'Newspaper' => 'mfp-newspaper',
        '3D Unfold' => 'mfp-3d-unfold'
      ),
      "description" => __("Choose your lightbox effect.", "js_composer")
    ),
    $element_options['class'],
    $element_options['id'],
    $element_options['css_animation'],
    $element_options['css_animation_delay'],
  )
);

}

vc_map( $md_shortcodes['md_lightbox_gallery'] );

class WPBakeryShortCode_MD_Lightbox_Gallery extends WPBakeryShortCode {}
<?php
/**
 *
 * MD Shortcodes Box
 *
 */


if(file_exists(get_template_directory().'/framework/shortcodes/lib/md_box.php')){
  require_once (get_template_directory().'/framework/shortcodes/lib/md_box.php');
}

else{

$md_shortcodes['md_box'] = array(
  "name"            => __("Box", "js_composer"),
  "base"            => "md_box",
  "modal"           => false,
  "params"          => array(
    array(
      "type"        => "textarea_html",
      "heading"     => __("Text", "js_composer"),
      "param_name"  => "content",
      "shortcode_btn"  => true,
      "value"       => ""
    ),
    array(
      "type"        => "radio",
      "heading"     => __("Box Style", "js_composer"),
      "param_name"  => "fill",
      "value"       => array(
        __('Fill', "js_composer")  => "fill", 
        __('No Fill', "js_composer")  => "no-fill", 
      ),
      "default"     => "fill"
    ),
    array(
      "type"        => "radio",
      "heading"     => __("Border", "js_composer"),
      "param_name"  => "border",
      "value"       => array(
        __('Yes', "js_composer") => "with-border", 
        __('No', "js_composer") => "no-border", 
      ),
      "default"     => "accent",
      "dependency"  => array('element' => 'fill', 'value' => 'fill')
    ),
    array(
      "type"        => "radio",
      "heading"     => __("Color Scheme", "js_composer"),
      "param_name"  => "color_scheme",
      "value"       => array(
        __('Accent Color', "js_composer") => "accent", 
        __('Custom', "js_composer") => "custom", 
      ),
      "default"     => "accent"
    ),
    array(
      "type"        => "colorpicker",
      "heading"     => __("Custom Color", "js_composer"),
      "param_name"  => "custom_color",
      "value"       => '#ffffff',
      "dependency"  => array('element' => 'color_scheme', 'value' => 'custom')
    ),
    $element_options['class'],
    $element_options['id'],
    $element_options['css_animation'],
    $element_options['css_animation_delay'],
  )
);

}

vc_map( $md_shortcodes['md_box'] );

class WPBakeryShortCode_MD_Box extends WPBakeryShortCode {}
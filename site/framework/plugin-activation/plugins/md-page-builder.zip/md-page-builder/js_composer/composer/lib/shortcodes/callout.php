<?php
/**
 *
 * MD Shortcodes Callout
 *
 */

if(file_exists(get_template_directory().'/framework/shortcodes/lib/md_callout.php')){
  require_once (get_template_directory().'/framework/shortcodes/lib/md_callout.php');
}

else{

$md_shortcodes['md_callout'] = array(
  "name"            => __("Callout", "js_composer"),
  "base"            => "md_callout",
  "modal"           => true,
  "params"          => array(
    array(
      "type"        => "textarea_html",
      "heading"     => __("Text", "js_composer"),
      "param_name"  => "content",
      "shortcode_btn"  => true,
      "value"       => ""
    ),
    array(
      "type"        => "textfield",
      "heading"     => __("Font Size", "js_composer"),
      "param_name"  => "font_size",
      "value"       => "40px",
      "description" => __("Set the font size (eg: 40px).", "js_composer")
    ),
    $element_options['class'],
    $element_options['id'],
    $element_options['css_animation'],
    $element_options['css_animation_delay'],
  )
);

}

vc_map( $md_shortcodes['md_callout'] );

class WPBakeryShortCode_MD_Callout extends WPBakeryShortCode {}
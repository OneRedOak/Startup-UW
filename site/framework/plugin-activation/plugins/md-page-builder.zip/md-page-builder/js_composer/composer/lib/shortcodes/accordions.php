<?php
/**
 *
 * MD Shortcodes Accordions
 *
 */

if(file_exists(get_template_directory().'/framework/shortcodes/lib/md_accordions.php')){
  require_once (get_template_directory().'/framework/shortcodes/lib/md_accordions.php');
}

else{

$md_shortcodes['md_accordions'] = array(
  "name"            => __("Accordions", "js_composer"),
  "base"            => "md_accordions",
  "modal"           => true,
  "params"          => array(
    array(
      "type"        => "radio",
      "heading"     => __("First Expanded?", "js_composer"),
      "param_name"  => "expanded",
      "value"       => array(
            __('Yes', "js_composer")     => "expanded", 
            __('No', "js_composer")  => "no-expanded", 
      ),
      "default"     => "expanded"
    ),
    array(
      "type"        => "radio",
      "heading"     => __("Accordion Style", "js_composer"),
      "param_name"  => "fill",
      "value"       => array(
        __('Fill', "js_composer")  => "fill", 
        __('No Fill', "js_composer")  => "no-fill", 
      ),
      "default"     => "fill"
    ),
    array(
      "type"        => "radio",
      "heading"     => __("Color Scheme", "js_composer"),
      "param_name"  => "color_scheme",
      "value"       => array(
        __('Accent Color', "js_composer") => "accent", 
        __('Custom', "js_composer") => "custom", 
      ),
      "default"     => "accent"
    ),
    array(
      "type"        => "colorpicker",
      "heading"     => __("Custom Color", "js_composer"),
      "param_name"  => "custom_color",
      "value"       => '#bbbbbb',
      "dependency"  => array('element' => 'color_scheme', 'value' => 'custom')
    ),
    array(
      "type"        => "textarea_html",
      "heading"     => __("Content", "js_composer"),
      "param_name"  => "content",
      "disable_modal" => true,
      "shortcode_btn"  => 'only',
      "shortcode"   => "md_accordions",
      "value"       => "",
      "description" => __("Highlight content for edit.", "js_composer"),
    ),
    array(
      "type"        => "custom",
      "param_name"  => "accordion",
      "name"        => "accordion",
    ),
    $element_options['class'],
    $element_options['id'],
    $element_options['css_animation'],
    $element_options['css_animation_delay'],
  )
);

}

vc_map($md_shortcodes['md_accordions']);

class WPBakeryShortCode_MD_Accordions extends WPBakeryShortCode {}



if(file_exists(get_template_directory().'/framework/shortcodes/lib/md_accordion.php')){
  require_once (get_template_directory().'/framework/shortcodes/lib/md_accordion.php');
}

else{

$md_shortcodes['md_accordion'] = array(
  "name"            => __("Accordion", "js_composer"),
  "base"            => "md_accordion",
  "content_element" => false,
  "modal"           => false,
);

}

vc_map($md_shortcodes['md_accordion']);

class WPBakeryShortCode_MD_Accordion extends WPBakeryShortCode_MD_Accordions {}


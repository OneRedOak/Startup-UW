<?php
/**
 *
 * MD Shortcodes Lighbox Image
 *
 */

if(file_exists(get_template_directory().'/framework/shortcodes/lib/md_lightbox_image.php')){
  require_once (get_template_directory().'/framework/shortcodes/lib/md_lightbox_image.php');
}

else{


$md_shortcodes['md_lightbox_image'] = array(
  "name"            => __("Lightbox Image", "js_composer"),
  "base"            => "md_lightbox_image",
  "modal"           => false,
  "params"          => array(
    array(
      "type"        => "attach_image",
      "heading"     => __("Thumb", "js_composer"),
      "param_name"  => "thumb",
      "description" => __("Choose your thumb.", "js_composer")
    ),
    array(
      "type"        => "attach_image",
      "heading"     => __("Big Image", "js_composer"),
      "param_name"  => "image",
      "description" => __("Choose your lightbox Big Image.", "js_composer")
    ),
    array(
      "type"        => "radio",
      "heading"     => __("Preview Size", "js_composer"),
      "param_name"  => "size",
      "value"       => array(
            __('Default', "js_composer") => "post-image", 
            __('Square', "js_composer") => "square-1", 
            __('Wide', "js_composer")  => "wide-1", 
            __('Tall', "js_composer")  => "tall-1", 
      ),
      "default"     => "post-image",
      "description" => __("Select preview size.", "js_composer")
    ),
    array(
      "type"        => "dropdown",
      "heading"     => __("Open Effect", "js_composer"),
      "param_name"  => "effect",
      "value"       => array(
        'Move Horizontal' => 'mfp-move-horizontal',
        'Move From Top' => 'mfp-move-from-top',
        'Zoom In'   => 'mfp-zoom-in',
        'Zoom Out'  => 'mfp-zoom-out',
        'Newspaper' => 'mfp-newspaper',
        '3D Unfold' => 'mfp-3d-unfold'
      ),
      "description" => __("Choose your lightbox effect.", "js_composer")
    ),
    $element_options['class'],
    $element_options['id'],
    $element_options['css_animation'],
    $element_options['css_animation_delay'],
  )
);

}

vc_map( $md_shortcodes['md_lightbox_image'] );

class WPBakeryShortCode_MD_Lightbox_Image extends WPBakeryShortCode {}
<?php

if(file_exists(get_template_directory().'/framework/shortcodes/templates/md_cta.php')){
  require_once (get_template_directory().'/framework/shortcodes/templates/md_cta.php');
}

else{

extract(shortcode_atts(array(
    'class' 		=> '',
    'id' 			=> '',
    'css_animation' => '',
    'css_animation_delay' => '',
    'color_scheme'	=> '',
    'bgcolor' 		=> ''
), $atts));


$animated = ($css_animation) ? 'animate' : '';
$css_animation_delay = ($css_animation) ? ' data-delay="'.$css_animation_delay.'"' : '';

$class  = setClass(array('md-cta', $animated, $css_animation, $class, $color_scheme));
$id     = setId($id);

$style = ($color_scheme == 'custom') ? ' style="background-color:'.$bgcolor.';"' : '';



$output .= '<div'.$class.$id.$style.$css_animation_delay.'>';
$output .= wpb_js_remove_wpautop($content);
$output .= '</div>';

echo $output;

}

<?php

if(file_exists(get_template_directory().'/framework/shortcodes/templates/md_shortcodes_list.php')){
  require_once (get_template_directory().'/framework/shortcodes/templates/md_shortcodes_list.php');
}

else{
?>

<h2 class="md-special-heading">Shortcodes</h2>
<nav id="menu-shortcodes">
	<ul>
		<?php 
		if(has_nav_menu('shortcodes_menu')) {
		wp_nav_menu( array('theme_location' => 'shortcodes_menu', 'menu' => 'Shortcodes Menu', 'container' => '', 'items_wrap' => '%3$s' ) ); 
		}
		else {
		echo '<li><a href="#">No menu assigned!</a></li>';
		}
		?>	
	</ul>
</nav>
<?php } ?>

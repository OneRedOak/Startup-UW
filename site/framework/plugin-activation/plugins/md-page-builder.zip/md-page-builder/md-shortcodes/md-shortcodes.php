<?php
/*
Plugin Name: MD Shortcodes.
Plugin URI: http://www.themesholic.com
Description: Shortcodes for Themesholic Themes.
Author: Themesholic
Author URI: http://www.themesholic.com
Version: 1.0
*/


define('MD_SHORTCODES_URI', plugin_dir_url( __FILE__ ));
define('MD_SHORTCODES_DIR', plugin_dir_path( __FILE__ ));


/*-----------------------------------------------------------------------------------*/
/*	Translation
/*-----------------------------------------------------------------------------------*/
load_plugin_textdomain( 'textdomain', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );


/*-----------------------------------------------------------------------------------*/
/*	Shortcodes
/*-----------------------------------------------------------------------------------*/
require_once( MD_SHORTCODES_DIR .'/tinymce/tinymce-class.php' );


/*-----------------------------------------------------------------------------------*/
/*	Register / Enqueue CSS
/*-----------------------------------------------------------------------------------*/
function md_shortcodes_backend() {
	wp_register_style('font-awesome', MD_SHORTCODES_URI . 'assets/css/font-awesome.min.css');
	wp_enqueue_style('font-awesome'); 

}
add_action('admin_init', 'md_shortcodes_backend');


/*-----------------------------------------------------------------------------------*/
/*	Register / Enqueue JS
/*-----------------------------------------------------------------------------------*/
function md_shortcodes_frontend() {
	wp_register_script('google-maps', 'http://maps.google.com/maps/api/js?sensor=false', NULL, NULL, true);
	wp_enqueue_script('google-maps');

	wp_register_style('font-awesome', MD_SHORTCODES_URI . 'assets/css/font-awesome.min.css');
	wp_enqueue_style('font-awesome'); 

	wp_register_script('jquery-easing', MD_SHORTCODES_URI.'assets/js/libs/jquery.easing.js', array('jquery'), '1.3.0', true);
	wp_enqueue_script('jquery-easing');	

	wp_deregister_script('isotope');
	wp_register_script('isotope', MD_SHORTCODES_URI.'assets/js/libs/jquery.isotope.js', array('jquery'), '1.5.25', true);
	wp_enqueue_script('isotope');

	wp_register_script('owl-carousel', MD_SHORTCODES_URI.'assets/js/libs/owl-carousel/owl.carousel.min.js', array('jquery'), '1.27', true);
	wp_enqueue_script('owl-carousel');
	wp_register_style('owl-carousel', MD_SHORTCODES_URI.'assets/js/libs/owl-carousel/owl.carousel.css');
	wp_enqueue_style('owl-carousel');

	wp_register_script('jquery-flexslider', MD_SHORTCODES_URI.'assets/js/libs/jquery.flexslider-min.js', array('jquery'), '2.2.0', true);
	wp_enqueue_script('jquery-flexslider');

	wp_register_script('jquery-magnific-popup', MD_SHORTCODES_URI.'assets/js/libs/magnific-popup/jquery.magnific-popup.min.js', array('jquery'), '0.9.9', true);
	wp_enqueue_script('jquery-magnific-popup');	
	wp_register_style('jquery-magnific-popup', MD_SHORTCODES_URI.'assets/js/libs/magnific-popup/magnific-popup.css');
	wp_enqueue_style('jquery-magnific-popup');	


	wp_register_script('jquery-fitvids', MD_SHORTCODES_URI . 'assets/js/libs/jquery.fitvids.js', array('jquery'), '1.0.3', true);
	wp_enqueue_script('jquery-fitvids');

	
	wp_register_script('mediaelement', MD_SHORTCODES_URI . 'assets/js/libs/mediaelement/mediaelement-and-player.min.js', array('jquery'), '2.13.1', true);
	wp_enqueue_script('mediaelement');
	wp_register_style('mediaelement', MD_SHORTCODES_URI . 'assets/js/libs/mediaelement/mediaelementplayer.min.css');
	wp_enqueue_style('mediaelement');


	wp_register_script('jquery-countTo', MD_SHORTCODES_URI . 'assets/js/libs/jquery.countTo.js', array('jquery'), '1.0', true);
	wp_enqueue_script('jquery-countTo');

	wp_register_script('jquery-viewport', MD_SHORTCODES_URI . 'assets/js/libs/jquery.viewport.js', array('jquery'), '1.0', true);
	wp_enqueue_script('jquery-viewport');

	wp_register_style('animate', MD_SHORTCODES_URI . 'assets/css/animate.css');

	wp_register_style('md-shortcodes', MD_SHORTCODES_URI . "assets/css/md-shortcodes.css");		 
	wp_enqueue_style('md-shortcodes');

	wp_register_script('md-shortcodes', MD_SHORTCODES_URI . "assets/js/md-shortcodes.js");		 
	wp_enqueue_script('md-shortcodes');
}
add_action('wp_enqueue_scripts', 'md_shortcodes_frontend');
?>
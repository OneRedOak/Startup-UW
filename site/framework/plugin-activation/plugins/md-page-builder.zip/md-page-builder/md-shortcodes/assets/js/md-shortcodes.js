/**
 *
 * MD Shortcodes
 *
 * v1.0.0
 *
 * http://themesholic.com
 *
 */

 (function($){

"use strict";

var MD_SHORTCODES = window.MD_SHORTCODES || {};

MD_SHORTCODES.sections = function(){
	function calculateSize(){
		var $container_w = $('.container').width();
		var $window_w = $('#wrap').width();

		$('.section-full-width-all .section-content').css({
			'margin-left' : - ($window_w - $container_w)/2,
			'width'	: $window_w
		});
	}
	calculateSize();

	$(window).smartresize(function(){
		calculateSize();
	})
}

MD_SHORTCODES.css3animations = function(){

	function animateElements(){
		$('.animate').scrolledIntoView().on('scrolledin', function () { 
			var $delay = $(this).data('delay');
			if($delay == ''){
				$delay = 0;
			}

			$(this).delay($delay).queue(function(){
				$(this).addClass('animated')
			});
		});
	}
	animateElements();

	function animationExample(){
		$('#md-animation-demo select').change(function(){
			var $anim = $(this).val();
			var $el = $('#el');
			
			$el.remove();
			$('#md-animation-demo').append('<div id="el"></div>');
			
			$el = $('#el');

			$el.removeClass();

			$el.addClass($anim).delay(100).queue(function(){
				$(this).addClass('animated')
			});

		});
	}
	animationExample();
}



MD_SHORTCODES.parallax = function(){
	
	$('[data-type]').each(function() {	
		$(this).data('offsetY', parseInt($(this).attr('data-offsetY')));
		$(this).data('Xposition', $(this).attr('data-Xposition'));
		$(this).data('speed', $(this).attr('data-speed'));
	});
	$('[data-type="background"]').each(function(){
		var $self = $(this),
			offsetCoords = $self.offset(),
			topOffset = offsetCoords.top;
	    $(window).scroll(function() {
			//if ( ($window.scrollTop() + $window.height()) > (topOffset) &&
			//	 ( (topOffset + $self.height()) > $window.scrollTop() ) ) {
				var yPos = -($(window).scrollTop() / $self.data('speed')); 
				if ($self.data('offsetY')) {
					yPos += $self.data('offsetY');
				}
				var coords = '50% '+ yPos + 'px';
				$self.css({ backgroundPosition: coords });
				$('[data-type="sprite"]', $self).each(function() {
					var $sprite = $(this);
					var yPos = -($(window).scrollTop() / $sprite.data('speed'));					
					var coords = $sprite.data('Xposition') + ' ' + (yPos + $sprite.data('offsetY')) + 'px';
					$sprite.css({ backgroundPosition: coords });													
				});
			// };
		});
	});
}



MD_SHORTCODES.buttons = function(){
	
	$('.md-button[data-hover]').not('.accent').each(function(){
		$(this).attr('data-default-colors', $(this).css('background-color')+'|'+$(this).css('color'));
	})
	
	$('.md-button[data-hover]').not('.accent').on('mouseover', function(){
		var $btn_hover = $(this).data('hover').split('|');
		$(this).css({
			'background-color' : $btn_hover[0],
			'color' : $btn_hover[1]
		});

		$(this).find('.md-icon').css({
			'color' : $btn_hover[1]
		});

	}).on('mouseleave', function(){
		var $btn_default = $(this).data('default-colors').split('|');
		
		$(this).css({
			'background-color' : $btn_default[0],
			'color' : $btn_default[1]
		});

		$(this).find('.md-icon').css({
			'color' : $btn_default[1]
		});
	})
}


MD_SHORTCODES.accordions = function(){
	$('.md-accordions .panel-group').each(function(){
		var $uid = $(this).attr('id');
		if($uid){
			$(this).find('.panel-heading a').data('parent', '#'+$uid);

			$(this).find('.panel-heading a').on('click', function(){
				$(this).parents('.panel-group').find('.panel-heading a').addClass('collapsed');
			})
		}
	});

	$('.md-accordions.expanded .panel-group').each(function(){
		$(this).find('.panel .panel-heading a:first').removeClass('collapsed');
		$(this).find('.panel .panel-collapse:first').removeClass('collapse').addClass('in');
	});
}



MD_SHORTCODES.tabs = function(){
	$('.md-tabs .nav-tabs a').each(function(){
		var $uid = $(this).attr('href').split('#').join('');
		var $pos = $('.md-tabs .nav-tabs a').index(this);

		$('.md-tabs .tab-pane').eq($pos).attr('id', $uid);
	});

	$('.md-tabs').each(function(){
		$(this).find('.nav-tabs li').eq(0).addClass('active');
		$(this).find('.tab-pane').eq(0).addClass('active');
	})
}


MD_SHORTCODES.alerts = function(){
    $('.md-alert .message-close').on('click', function(){
    	$(this).parents('.md-alert').fadeOut();

    	return false;
    });
}


MD_SHORTCODES.tooltip = function(){ 
    $('[data-toggle=tooltip]').tooltip();
};


MD_SHORTCODES.googleMap = function(){
	if($('.md-map').length > 0){
		$('.md-map').each(function(i, e){

			var $map 		= $(e);
			var $map_id 	= $map.attr('id');
			var $map_type 	= $map.data('map-type');

			var $map_lat 	= $map.data('map-lat');
			var $map_lon 	= $map.data('map-lon');
			var $map_zoom 	= parseInt($map.data('map-zoom'));
			var $map_pin 	= $map.data('map-pin');
			var $map_title 	= $map.data('map-title');
			var $map_info 	= $map.data('map-info');
			var $map_scroll = $map.data('map-scroll');
			var $map_drag 	= $map.data('map-drag');
			var $map_zoom_control = $map.data('map-zoom-control');
			var $map_disable_doubleclick = $map.data('map-disable-doubleclick');
			var $map_streetview = $map.data('map-streetview');

			
			
			var latlng = new google.maps.LatLng($map_lat, $map_lon);			
			var options = { 
				scrollwheel: $map_scroll,
				draggable: $map_drag, 
				zoomControl: $map_zoom_control,
				disableDoubleClickZoom: $map_disable_doubleclick,
				zoom: $map_zoom,
				center: latlng,
				streetViewControl: $map_streetview
			};

			switch ($map_type){
				case 'HYBRID':
					options.mapTypeId = google.maps.MapTypeId.HYBRID;
				break;
				case 'ROADMAP':
					options.mapTypeId = google.maps.MapTypeId.ROADMAP;
				break;
				case 'SATELLITE':
					options.mapTypeId = google.maps.MapTypeId.SATELLITE;
				break;
				case 'TERRAIN':
					options.mapTypeId = google.maps.MapTypeId.TERRAIN;
				break;
			}
			
			var map = new google.maps.Map(document.getElementById($map_id), options);
			
			if($map_pin){
				var marker = new google.maps.Marker({
					position: latlng,
					map: map,
					title: $map_title,
					icon: $map_pin
				});
			
				if($map_info){		
					var infowindow = new google.maps.InfoWindow({
						content: $map_info
					});


					google.maps.event.addListener(marker, 'click', function() {
		      			infowindow.open(map, marker);
		    		});
				}	
			}
		});
	}
}

MD_SHORTCODES.postsCarousel = function(){ 
    $('.md-posts-grid.carousel').owlCarousel({
	    items : 3,
	    itemsDesktop : [1199,3],
	    itemsDesktopSmall : [980,3],
	    itemsTablet: [768,2],
	    itemsMobile : [479,1],
        navigation : true,
    	slideSpeed : 500,
    	navigationText: ['<i class="icon-angle-left"></i>', '<i class="icon-angle-right"></i>']
    });
};


MD_SHORTCODES.testimonialsCarousel = function(){ 
    $('.md-testimonials.carousel').owlCarousel({
    	items : 1,
    	itemsDesktop: false,
    	itemsDesktopSmall : false,
    	itemsTablet : false,
    	itemsMobile : false,
	    navigation : false,
	    pagination : true,
	    singleItem : true,
    	transitionStyle : "fade",
    	navigationText: ['<i class="icon-angle-left"></i>', '<i class="icon-angle-right"></i>']
    });
};


MD_SHORTCODES.clientsCarousel = function(){ 
    $('.md-clients.carousel').owlCarousel({
    	navigation : true,
    	slideSpeed : 500,
    	navigationText: ['<i class="icon-angle-left"></i>', '<i class="icon-angle-right"></i>']
    });
};

MD_SHORTCODES.twitterCarousel = function(){ 
    $('.md-twitter-feed.carousel').owlCarousel({
    	items : 1,
    	itemsDesktop: false,
    	itemsDesktopSmall : false,
    	itemsTablet : false,
    	itemsMobile : false,
	    navigation : false,
	    pagination : true,
	    singleItem : true,
	    autoPlay: true,
    	transitionStyle : "fade",
    	navigationText: ['<i class="icon-angle-left"></i>', '<i class="icon-angle-right"></i>']
    });
};

MD_SHORTCODES.portfolioCarousel = function(){ 
     $('.md-portfolio-grid.carousel').each(function(){
     	var $portfolio = $(this);
     	var $items = $portfolio.data('items-desktop');
     	var $items_tablet = $portfolio.data('items-tablet');
	    
	    $portfolio.owlCarousel({
		    items : $items,
		    itemsDesktop : [1199,$items],
		    itemsDesktopSmall : [980,$items],
		    itemsTablet: [768,$items_tablet],
		    itemsMobile : [479,1],
	        navigation : true,
	    	slideSpeed : 500,
	    	navigationText: ['<i class="icon-angle-left"></i>', '<i class="icon-angle-right"></i>']
	    });

     });
};


MD_SHORTCODES.customCarousel = function(){ 
    $('.md-carousel').each(function(){
    	var $carousel = $(this);
    	var $carousel_items = $carousel.data('items');
    	var $carousel_items_desktop = $carousel.data('items-desktop');
    	var $carousel_items_tablet = $carousel.data('items-tablet');
    	var $carousel_items_mobile = $carousel.data('items-mobile');

	    $carousel.owlCarousel({
		    items : $carousel_items,
		    itemsDesktop : [1199,$carousel_items_desktop],
		    itemsDesktopSmall : [980,$carousel_items_tablet],
		    itemsTablet: [768,$carousel_items_tablet],
		    itemsMobile : [479,$carousel_items_mobile],
	        navigation : true,
	    	slideSpeed : 500,
	    	navigationText: ['<i class="icon-angle-left"></i>', '<i class="icon-angle-right"></i>']
	    });
    });
};


MD_SHORTCODES.portfolioIsotope = function(){ 
	$('.md-portfolio-grid.filter').isotope({
		itemSelector : '.item',
		layoutMode : 'fitRows'

	});

	$('.md-portfolio-filter a').on('click', function(){
	  var selector = $(this).attr('data-filter');
	  $('.md-portfolio-filter a').removeClass('active');
	  $(this).addClass('active');
	  $('.md-portfolio-grid.filter').isotope({ filter: selector });
	  return false;
	});
};


MD_SHORTCODES.flexslider = function(){
	$('.flexslider').flexslider({
		controlNav 	 : false,
		smoothHeight : true,
		prevText	 : '<i class="icon-chevron-left"></i>',
		nextText	 : '<i class="icon-chevron-right"></i>'
	});	
}


MD_SHORTCODES.backToTop = function(){	
	$(window).scroll(function(){
		if($(window).scrollTop() > 100){
			$('#md-back-top').css({'bottom' : 0});
		}
		else{
			$('#md-back-top').css({'bottom' : -$('#md-back-top').height()});
		}
	});

	$('#md-back-top').on('click', function(){

		$('body, html').animate({scrollTop: 0 }, 800, 'easeInOutExpo');

		return false;
	})
}

MD_SHORTCODES.arrowPageHeader = function(){
	function hex(x) {return ("0" + parseInt(x).toString(16)).slice(-2);}
	if($('.md-page-header .arrow.arrow-in').length){
		var $arrow = $('.md-page-header .arrow.arrow-in');
		var $nextSection = $arrow.parent('.md-page-header').next('section');

		if($nextSection.length){

			var $nextColor = $nextSection.css('background-color');
			
			if($nextColor){
				var $rgb = $nextColor.match(/^rgb\((\d+),\s*(\d+),\s*(\d+)\)$/); 
				if ($rgb) {
					return "#" + hex($rgb[1]) + hex($rgb[2]) + hex($rgb[3]);
				} else {
					return $rgb;
				}

				alert($rgb);
				$arrow.css('border-bottom-color', $rgb);
			}
		}
	}
}


MD_SHORTCODES.socialShare = function(){

	function sharePopup(url){
		var width = 600;
		var height = 400;
	    
	    var leftPosition, topPosition;
	    leftPosition = (window.screen.width / 2) - ((width / 2) + 10);
	    topPosition = (window.screen.height / 2) - ((height / 2) + 50);

	    var windowFeatures = "status=no,height=" + height + ",width=" + width + ",resizable=yes,left=" + leftPosition + ",top=" + topPosition + ",screenX=" + leftPosition + ",screenY=" + topPosition + ",toolbar=no,menubar=no,scrollbars=no,location=no,directories=no";

	    window.open(url,'Social Share', windowFeatures);
	}

	$('#share-facebook').on('click', function(){
	    var u = location.href;
	    var t = document.title;
		sharePopup('http://www.facebook.com/sharer.php?u='+encodeURIComponent(u)+'&t='+encodeURIComponent(t));
		return false;
	});


	$('#share-twitter').on('click', function(){
	    var u = location.href;
	    var t = document.title;
		sharePopup('http://twitter.com/share?url='+encodeURIComponent(u)+'&text='+encodeURIComponent(t));
		return false;
	});

	$('#share-google').on('click', function(){
	    var u = location.href;
	    var t = document.title;
		sharePopup('https://plus.google.com/share?url='+encodeURIComponent(u)+'&text='+encodeURIComponent(t));
		return false;
	});

	$('#share-pinterest').on('click', function(){
	    var u = location.href;
	    var t = document.title;
	    var i = $('#content').find('img').eq(0).attr('src');
		sharePopup('http://www.pinterest.com/pin/create/button/?url='+encodeURIComponent(u)+'&description='+encodeURIComponent(t)+'&media='+encodeURIComponent(i));
		return false;
	});

	
	// Loading SDK
	if( $('.fb-like').length > 0 || $('.twitter-share-button').length > 0 || $('.g-plusone').length > 0 || $('.pinterest-share').length > 0) {

	    //Twitter
	    if (typeof (twttr) != 'undefined') {
	        twttr.widgets.load();
	    } else {
	        $.getScript('http://platform.twitter.com/widgets.js');
	    }

	    //Facebook
	    if (typeof (FB) != 'undefined') {
	        FB.init({ status: true, cookie: true, xfbml: true });
	    } else {
	        $.getScript("http://connect.facebook.net/en_US/all.js#xfbml=1", function () {
	            FB.init({ status: true, cookie: true, xfbml: true });
	        });
	    }

	    // Pinterest
	    if (typeof (pinterest) != 'undefined') {
		    pinterest.widgets.load();
		} else {
			$.getScript('http://assets.pinterest.com/js/pinit.js');
		}
	  
	    //Google - Note that the google button will not show if you are opening the page from disk - it needs to be http(s)
	    if (typeof (gapi) != 'undefined') {
	        $(".g-plusone").each(function () {
	            gapi.plusone.render($(this).get(0));
	        });
	    } else {
	        $.getScript('https://apis.google.com/js/plusone.js');
	    }

	}
}


MD_SHORTCODES.magnificPopup = function(){

	$('.lightbox-image').magnificPopup({
		type: 'image',
		removalDelay: 500,
		callbacks: {
			beforeOpen: function() {
				this.st.image.markup = this.st.image.markup.replace('mfp-figure', 'mfp-figure mfp-with-anim');
				this.st.mainClass = this.st.el.attr('data-effect');
			}
		},
		closeOnContentClick: true,
		midClick: true
	});

	$('.lightbox-map').magnificPopup({
		type: 'iframe',
		removalDelay: 500,
		closeOnContentClick: true,
		midClick: true
	});

	$('.lightbox-video').magnificPopup({
		type: 'iframe',
		removalDelay: 500,
		closeOnContentClick: true,
		midClick: true
	});

	$('.md-gallery-lightbox').each(function() { 
	    
	    $(this).magnificPopup({
	        delegate: 'a', 
			mainClass : 'mfp-fade',
	        type: 'image',
	        gallery:{enabled:true}
	    });
	});
}

MD_SHORTCODES.mediaElements = function(){
	$('.section-video video').mediaelementplayer({
		startVolume: 0,
		success: function (mediaElement, domObject) { 
        	mediaElement.play();
    	}
    });

	$('.md-video-hosted video').mediaelementplayer();
	$('.md-audio-hosted audio').mediaelementplayer();

	$('.section-video video, .md-video-hosted video').fitVids();
	
}


MD_SHORTCODES.counter = function(){
	
	$('.md-counter .number').scrolledIntoView().on('scrolledin', function () {
		if(!$(this).hasClass('end')){
			var $from = $(this).data('from'); 
			var $to = $(this).data('to'); 
			var $speed = $(this).data('speed'); 
			var $delay = $(this).data('delay');
			
			$(this).delay($delay).queue(function(){
				$(this).addClass('end').countTo({
					from: $from,
					to: $to,
					speed: $speed
				});
			});

		}
	});

}

MD_SHORTCODES.progressBar = function(){
	$('.md-progress-bar').scrolledIntoView().on('scrolledin', function () { 
		var $progress_width = $(this).find('span').data('percent');
		$(this).find('span').animate({
			width : $progress_width+'%'
		}, 800, 'easeInOutExpo');
	});
}


$(function(){
	MD_SHORTCODES.sections();
	MD_SHORTCODES.css3animations();
	MD_SHORTCODES.parallax();
	MD_SHORTCODES.buttons();
	MD_SHORTCODES.accordions();
	MD_SHORTCODES.tabs();
	MD_SHORTCODES.alerts();
	MD_SHORTCODES.tooltip();
	MD_SHORTCODES.googleMap();
	MD_SHORTCODES.postsCarousel();
	MD_SHORTCODES.testimonialsCarousel();
	MD_SHORTCODES.clientsCarousel();
	MD_SHORTCODES.twitterCarousel();
	MD_SHORTCODES.customCarousel();
	MD_SHORTCODES.portfolioCarousel();
	MD_SHORTCODES.portfolioIsotope();
	MD_SHORTCODES.flexslider();
	MD_SHORTCODES.backToTop();
	MD_SHORTCODES.arrowPageHeader();
	MD_SHORTCODES.socialShare();
	MD_SHORTCODES.magnificPopup();
	MD_SHORTCODES.mediaElements();
	MD_SHORTCODES.counter();
	MD_SHORTCODES.progressBar();
});

})(jQuery);